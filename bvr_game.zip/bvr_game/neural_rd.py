import numpy as np
import torch
from torch import nn
from torch import optim
import torch.nn.functional as F
import collections
from open_spiel.python.pytorch.losses import rl_losses
from open_spiel.python.pytorch.dqn import SonnetLinear
import gym
import gym_bvr
import time


env = gym.make("PyBVR2D-v0")
Transition = collections.namedtuple("Transition", "state action reward")

'''
a = Transition(state = [22,2],action = np.array([3,3]),reward= 3,discount = 4)
print(a.state)
'''


class MLPTorso(nn.Module):
    """A specialized half-MLP module when constructing multiple heads.
  Note that every layer includes a ReLU non-linearity activation.
  """

    def __init__(self, input_size, hidden_sizes):
        """Create the MLPTorso.
    Args:
      input_size: (int) number of inputs
      hidden_sizes: (list) sizes (number of units) of each hidden layer
    """

        super(MLPTorso, self).__init__()
        self._layers = []
        # Hidden layers
        for size in hidden_sizes:
            self._layers.append(SonnetLinear(in_size=input_size, out_size=size))
            input_size = size

        self.model = nn.ModuleList(self._layers)

    def forward(self, x):
        for layer in self.model:
            x = layer(x)
        return x


class MyNeurd():
    def __init__(self,
                 env,
                 max_global_gradient_norm,
                 num_critic_before_pi=5,
                 entropy_cost = 0.1,
                 hidden_layers_sizes=(128,),
                 state_size=53,
                 pi_learning_rate=0.001,
                 optimizer_str="adam",
                 critic_learning_rate=0.01,
                 ):


        self.env = env
        self.episode_counter = 0
        self.dataset = collections.defaultdict(list)
        self.episode_data = []
        self.num_learn_steps = 0
        self.num_critic_before_pi = num_critic_before_pi
        self.discount = 0.99
        self.max_global_gradient_norm = max_global_gradient_norm

        self.batch_size = 256
        self.ppo_epochs = 10
        self.m_reg = 10000

        self.layer_sizes = hidden_layers_sizes
        self.net_torso = MLPTorso(state_size, self.layer_sizes)
        #----------------- regularization ------------------#
        self.reg_torso = MLPTorso(state_size,self.layer_sizes)

        torso_out_size = self.layer_sizes[-1]
        self.num_actions = 6
        self.policy_logits_layer = SonnetLinear(torso_out_size, self.num_actions, activate_relu=False)
        # ----------------- regularization ------------------#
        self.reg_policy_logits_layer = SonnetLinear(torso_out_size, self.num_actions, activate_relu=False)


        self.loss_class = self.get_loss_class("neurd")
        self.pg_class = self.loss_class(entropy_cost=entropy_cost)

        if self.loss_class.__name__ == "BatchA2CLoss":
            self.baseline_layer = SonnetLinear(torso_out_size, 1, activate_relu=False)
            self.critic_network = nn.Sequential(self.net_torso, self.baseline_layer)
        else:
            self.q_values_layer = SonnetLinear(torso_out_size, self.num_actions, activate_relu=False)
            self.critic_network = nn.Sequential(self.net_torso, self.q_values_layer)

        if optimizer_str == "adam":
            self.critic_optimizer = optim.Adam(self.critic_network.parameters(), lr=critic_learning_rate)
        elif optimizer_str == "sgd":
            self.critic_optimizer = optim.SGD(self.critic_network.parameters(), lr=critic_learning_rate)

        self.pi_network = nn.Sequential(self.net_torso, self.policy_logits_layer)

        if optimizer_str == "adam":
            self.pi_optimizer = optim.Adam(self.pi_network.parameters(), lr=pi_learning_rate)
        elif optimizer_str == "sgd":
            self.pi_optimizer = optim.SGD(self.pi_network.parameters(), lr=pi_learning_rate)


    def get_loss_class(self, loss_str):
        if loss_str == "rpg":
            return rl_losses.BatchRPGLoss
        elif loss_str == "qpg":
            return rl_losses.BatchQPGLoss
        elif loss_str == "rm":
            return rl_losses.BatchRMLoss
        elif loss_str == "a2c":
            return rl_losses.BatchA2CLoss
        elif loss_str == "neurd":
            return rl_losses.BatchNeuRDLoss
        elif loss_str == "neurdppo":
            return rl_losses.BatchNeuRDPPOLoss

    def act_help(self, state,player):


        state = torch.Tensor(np.reshape(state, [1, -1]))
        torso_out = self.net_torso(state)
        self.policy_logits = self.policy_logits_layer(torso_out)
        policy_probs = F.softmax(self.policy_logits, dim=1).detach()

        probs = np.zeros(self.num_actions)
        probs[::] = policy_probs[0][::]
        if sum(probs) != 0:
            probs /= sum(probs)
        else:
            probs[0] = 0.5
            probs[2] = 0.5

        action = np.random.choice(len(probs), p=probs)

        return action

    def act(self, red_state, blue_state):
        red_action = self.act_help(red_state,0)
        blue_action = self.act_help(blue_state,1)
        return [red_action, blue_action]

    def step(self, red_state, blue_state):


        red_action, blue_action = self.act(red_state, blue_state)
        s_, r_reward, done, info = env.step([red_action, blue_action])

        new_red = s_[:53]
        new_blue = s_[53:]
        # .......................   begin data collection  ...................... #

        for state_,action_,reward_ in [[red_state,red_action,r_reward],[blue_state,blue_action,info['blue_reward']]]:

            state_tensor = torch.unsqueeze(torch.Tensor(state_),dim=0)
            torso_out = self.net_torso(state_tensor)
            policy_logits = self.policy_logits_layer(torso_out)
            current_policy_probs = F.softmax(policy_logits, dim=1).squeeze(0)
            current_action_prob = current_policy_probs[action_]

            with torch.no_grad():
                reg_out = self.reg_torso(state_tensor)
                reg_policy_logits = self.reg_policy_logits_layer(reg_out)
                reg_policy_probs = F.softmax(reg_policy_logits,dim = 1).detach().squeeze(0)
                reg_action_prob = reg_policy_probs[action_]

            reward_ = reward_ - 0.1 * torch.log(current_action_prob/reg_action_prob)
            self.add_transition(state_, action_, reward_)


        # .......................   END data collection  ...................... #

        if done:
            for _ in range(self.m_reg):

                self.add_episode_data_to_dataset()
                self.episode_counter += 1

                if len(self.dataset['actions']) >= self.batch_size:
                    ppo_actions = torch.LongTensor(self.dataset["actions"]).view(-1,1)
                    ppo_state = torch.Tensor(np.array(self.dataset["states"]))
                    torso_out = self.net_torso(ppo_state)
                    ppo_policy_logits = self.policy_logits_layer(torso_out)
                    ppo_policy_probs = F.softmax(ppo_policy_logits, dim=1)
                    self.ppo_old_log_probs = torch.log(ppo_policy_probs).gather(1, ppo_actions).detach()

                    for _ in range(self.ppo_epochs):
                        self.critic_update()
                        self.num_learn_steps += 1

                        if self.num_learn_steps % self.num_critic_before_pi == 0:
                            self.pi_update()

                    self.dataset = collections.defaultdict(list)

            #------------------ update regularization net paramters -----------------------#
            for param_reg,param in zip(self.reg_torso.parameters(),self.net_torso.parameters()):
                param_reg.data = param.detach().data

            for param_reg,param in zip(self.reg_policy_logits_layer.parameters(),self.policy_logits_layer.parameters()):
                param_reg.data = param.detach().data
            #------------------------------------------------------------------------------#

        return done, new_red, new_blue,info


    def add_transition(self, state, action, reward):
        transition = Transition(state=state, action=action, reward=reward)
        self.episode_data.append(transition)
        return

    def add_episode_data_to_dataset(self):

        states = [data.state for data in self.episode_data]
        rewards = [data.reward.clone().detach() for data in self.episode_data]
        actions = [data.action for data in self.episode_data]

        returns = np.array(rewards)
        for idx in reversed(range(len(rewards) - 1)):
            returns[idx] = (rewards[idx] + self.discount * returns[idx + 1])

        self.dataset["returns"].extend(returns)
        self.dataset["states"].extend(states)
        self.dataset["actions"].extend(actions)

        self.episode_data = []

    def minimize_with_clipping(self, model, optimizer, loss):
        optimizer.zero_grad()
        loss.backward()
        if self.max_global_gradient_norm is not None:
            nn.utils.clip_grad_norm_(model.parameters(), self.max_global_gradient_norm)
        optimizer.step()

    def critic_update(self):
        info_state = torch.Tensor(self.dataset["states"])
        action = torch.LongTensor(self.dataset["actions"])
        return_ = torch.Tensor(self.dataset["returns"])
        torso_out = self.net_torso(info_state)

        # Critic loss
        # Baseline loss in case of A2C
        if self.loss_class.__name__ == "BatchA2CLoss":
            baseline = torch.squeeze(self.baseline_layer(torso_out), dim=1)
            critic_loss = torch.mean(F.mse_loss(baseline, return_))
            self.minimize_with_clipping(self.baseline_layer, self.critic_optimizer, critic_loss)
        else:
            # Q-loss otherwise.
            q_values = self.q_values_layer(torso_out)
            action_indices = torch.stack([torch.arange(q_values.shape[0], dtype=torch.long), action], dim=0)
            value_predictions = q_values[list(action_indices)]
            critic_loss = torch.mean(F.mse_loss(value_predictions, return_))
            self.minimize_with_clipping(self.q_values_layer, self.critic_optimizer, critic_loss)
        self.last_critic_loss_value = critic_loss
        return critic_loss

    def pi_update(self):

        state = torch.Tensor(np.array(self.dataset["states"]))
        torso_out = self.net_torso(state)
        self.policy_logits = self.policy_logits_layer(torso_out)
        current_policy_probs = F.softmax(self.policy_logits, dim=1)
        log_current_policy_probs = torch.log(current_policy_probs)

        q_values = self.q_values_layer(torso_out)
        pi_loss = self.pg_class.loss(policy_logits=self.policy_logits, action_values=q_values)
        self.minimize_with_clipping(self.policy_logits_layer, self.pi_optimizer, pi_loss)

        self.last_pi_loss_value = pi_loss
        return pi_loss

    @property
    def loss(self):
        return (self.last_critic_loss_value, self.last_pi_loss_value)

