import numpy as np
import collections
import torch.nn.functional as F
import torch
import random
import gym
import tqdm
import os
import utils.exploration as exploration
from networks.networks import *


# os.environ["CUDA_VISIBLE_DEVICES"] = ""

class ReplayBuffer:
    def __init__(self, capacity):
        self.buffer = collections.deque([], maxlen=capacity)  # 队列,先进先出

    def add(self, state, action, reward, next_state, done):  # 将数据加入buffer
        self.buffer.appendleft([state, action, reward, next_state, done])  # [tn, tn-1, ..., t0, tn, tn-1, ...]

    def sample(self, batch_size):  # 从buffer中采样数据,数量为batch_size
        transitions = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = zip(*transitions)
        return np.array(state), action, reward, np.array(next_state), done

    def calc_return(self, gamma):
        if len(self.buffer) <= 1:
            return
        for i in range(1, len(self.buffer)):
            if not self.buffer[i][4]:  # if NOT term
                self.buffer[i][2] = gamma * self.buffer[i - 1][2]
            else:
                return

    def size(self):  # 目前buffer中数据的数量
        return len(self.buffer)

    def clear(self):
        self.buffer.clear()


class DQN:
    def __init__(self,
                 action_dim,
                 state_dim,
                 depth,
                 width,
                 gamma=0.9):
        self.action_dim = action_dim
        self.state_dim = state_dim
        self.depth = depth
        self.width = width
        self.gamma = gamma
        self.count = 0
        self.device = torch.device("cuda") \
            if torch.cuda.is_available() else torch.device("cpu")

        self.q_net = MLP(state_dim, depth,
                         width, action_dim).to(self.device)
        self.gamma = gamma

    def choose_action(self, ob, explore=exploration.e_greedy, explore_kwargs=None):
        if explore_kwargs is None:
            explore_kwargs = {'epsilon': 0}
        ob = torch.tensor(ob).to(self.device)
        qas = self.q_net(ob).detach().cpu().numpy()
        q_max = qas.max()
        a = explore(qas, **explore_kwargs)
        return a, q_max

    def calc_td_loss(self, ob, a, r, ob_nx, term, tgt_net):  # 1-step TD target
        ob = torch.tensor(ob, dtype=torch.float).to(self.device)
        a = torch.tensor(a, dtype=torch.int64).view(-1, 1).to(self.device)
        r = torch.tensor(r, dtype=torch.float).view(-1, 1).to(self.device)
        ob_nx = torch.tensor(ob_nx, dtype=torch.float).to(self.device)
        term = torch.tensor(term, dtype=torch.float).view(-1, 1).to(self.device)
        q_a = self.q_net(ob).gather(1, a)
        max_q_a_nx = tgt_net(ob_nx).max(1)[0].view(-1, 1).detach()
        q_tgt = r + self.gamma * max_q_a_nx * (1 - term)
        loss = F.mse_loss(q_a, q_tgt)
        return loss

    def calc_mc_loss(self, ob, a, ret):  # Monte Carlo target
        ob = torch.tensor(ob, dtype=torch.float).to(self.device)
        a = torch.tensor(a, dtype=torch.int64).view(-1, 1).to(self.device)
        ret = torch.tensor(ret, dtype=torch.float).to(self.device)
        q_a = self.q_net(ob).gather(1, a)
        q_tgt = ret.view(-1, 1).detach()
        loss = F.mse_loss(q_a, q_tgt)
        return loss

    def train(self,
              env,
              lr,
              buffer_size,
              batch_size,
              tgt_update,
              num_episode,
              explore,
              explore_kwargs=None):
        explore_kwargs = {} if explore_kwargs is None else explore_kwargs
        tgt_q_net = MLP(self.state_dim, self.depth,
                        self.width, self.action_dim).to(self.device)

        optimizer = torch.optim.Adam(self.q_net.parameters(), lr=lr)
        replay_buffer = ReplayBuffer(buffer_size)
        step_ctr = 0
        with tqdm.tqdm(total=num_episode) as pbar:
            last_n_epi_ret = np.zeros(500)
            # while last_n_epi_ret.mean() < 90:  # until learned a good Q
            for epi in range(num_episode):
                epi_ret = 0
                ob, _ = env.reset()
                term = False
                # epi_len = 0
                while not term:  # one episode
                    # epi_len += 1
                    a, _ = self.choose_action(ob, explore=explore,
                                              explore_kwargs=explore_kwargs)
                    ob_nx, r, term, _, _ = env.step(a)
                    replay_buffer.add(ob, a, r, ob_nx, term)
                    if term:  # reward => return, monte carlo target only
                        replay_buffer.calc_return(self.gamma)
                    ob = ob_nx
                    epi_ret += r
                    if replay_buffer.size() > batch_size:
                        b_ob, b_a, b_r, b_ob_nx, b_term = replay_buffer.sample(batch_size)
                        # loss = self.calc_td_loss(b_ob, b_a, b_r, b_ob_nx, b_term, tgt_q_net)
                        loss = self.calc_mc_loss(b_ob, b_a, b_r)  # monte carlo target
                        optimizer.zero_grad()
                        loss.backward()
                        optimizer.step()

                        if step_ctr % tgt_update == 0:
                            tgt_q_net.load_state_dict(self.q_net.state_dict())
                        step_ctr += 1
                last_n_epi_ret[1:] = last_n_epi_ret[0:-1]
                last_n_epi_ret[0] = epi_ret
                pbar.set_postfix({'<last 500 epi avg ret>': last_n_epi_ret.mean()})
                pbar.update(1)

                rec.append(last_n_epi_ret.mean())
                # print(epi_len)

    def play_one_epi(self, env):
        ob, _ = env.reset()
        term = False
        ret = 0
        while not term:
            a, _ = self.choose_action(ob, explore=exploration.e_greedy, explore_kwargs={'epsilon': 0})  # greedy
            ob, r, term, _, _ = env.step(a)
            ret += r
            env.render()
        return ret


def evaluation(env, agent, epi):
    R_total = 0
    for _ in tqdm.tqdm(range(epi)):
        R_total += agent.play_one_epi(env)
    return R_total / epi


if __name__ == '__main__':
    env = gym.make('soccer_offense:soccer_offense/SoccerOffense-v0',
                   render_mode=None, goalie_mode='chase')

    rec = []
    agent = DQN(action_dim=8, state_dim=12, depth=2, width=256,
                gamma=0.9)

    agent.train(
        env=env,
        lr=1e-4,
        buffer_size=3000,
        batch_size=2048,
        tgt_update=10,
        num_episode=20000,
        explore=exploration.EGreedy(epsilon=0.1),
        explore_kwargs={}
    )
    rec = np.array(rec)
    evl = evaluation(env, agent, 500)
    np.savetxt('./e_greedy_mc_({:.2f}).txt'.format(evl), rec, delimiter=',')


    rec = []
    agent = DQN(action_dim=8, state_dim=12, depth=2, width=256,
                gamma=0.9)

    agent.train(
        env=env,
        lr=1e-4,
        buffer_size=3000,
        batch_size=2048,
        tgt_update=10,
        num_episode=20000,
        explore=exploration.RNDUCT(
            state_dim=12,
            lr=1e-4,
            env=env
        ),
        explore_kwargs={}
    )
    rec = np.array(rec)
    evl = evaluation(env, agent, 500)
    np.savetxt('./rnduct_mc_({:.2f}).txt'.format(evl), rec, delimiter=',')
