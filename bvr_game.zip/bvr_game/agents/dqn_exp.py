import numpy as np
import collections
import torch.nn.functional as F
import torch
import random
import gym
import tqdm
import os
import utils.exploration as exploration
from networks.networks import *

from agents.dqn import *


class DQNZ(DQN):
    def __init__(
            self,
            action_dim,
            state_dim,
            depth,
            width,
            gamma=0.9
    ):
        super(DQNZ, self).__init__(action_dim, state_dim, depth, width)
        # self.action_dim = action_dim
        # self.state_dim = state_dim
        # self.depth = depth
        # self.width = width
        self.gamma = gamma
        self.count = 0
        self.device = torch.device("cuda") \
            if torch.cuda.is_available() else torch.device("cpu")

        self.gamma = gamma

        self.q_torso = MLP(state_dim, depth - 1, width, width).to(self.device)
        self.q_head = nn.Sequential(
            nn.ReLU(),
            nn.Linear(width, action_dim)
        ).to(self.device)
        self.q_net = nn.Sequential(
            self.q_torso,
            self.q_head
        ).to(self.device)

    def choose_action(self, ob, explore=exploration.e_greedy, explore_kwargs=None):
        ob = torch.tensor(ob).to(self.device)
        with torch.no_grad():
            z = self.q_torso(ob)
            qas = self.q_head(z).detach().cpu().numpy()
        q_max = qas.max()

        ucts = np.zeros_like(qas)

    def nov(self):
        pass


if __name__ == '__main__':
    rec = []
    env = gym.make('soccer_offense:soccer_offense/SoccerOffense-v0',
                   render_mode=None, goalie_mode='chase')

    agent = DQNZ(action_dim=8, state_dim=14, depth=2, width=256,
                gamma=0.9)

    agent.train(
        env=env,
        lr=1e-4,
        buffer_size=3000,
        batch_size=2048,
        tgt_update=10,
        num_episode=20000,
        explore=exploration.EGreedy(epsilon=0.1),
        explore_kwargs={}
    )
    rec = np.array(rec)
    evl = evaluation(env, agent, 500)
    np.savetxt('./e_greedy{:.2f}.txt'.format(evl), rec, delimiter=',')
