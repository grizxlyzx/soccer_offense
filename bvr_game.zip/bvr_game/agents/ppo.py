import gym
import numpy as np
import torch
import torch.nn as nn
import os
import torch.optim as optim
import torch.nn.functional as F
import tqdm
from torch.distributions.categorical import Categorical
import utils.exploration as exploration
from networks.networks import *

# os.environ["CUDA_VISIBLE_DEVICES"] = ""


class ReplayBuffer:
	def __init__(self, max_len, n_envs, ob_shape, a_shape, n_a, device):
		self.max_len = max_len
		self.n_envs = n_envs
		self.ob_shape = ob_shape
		self.a_shape = a_shape
		self.n_a = n_a
		self.device = device
		self.ptr = self.max_len - 1  # from right most element
		self.obs = torch.zeros((max_len, n_envs) + ob_shape).to(device)
		self.actions = torch.zeros((max_len, n_envs) + a_shape).to(device)
		self.log_probs = torch.zeros((max_len, n_envs)).to(device)
		self.dist = torch.zeros((max_len, n_envs) + (n_a,) + a_shape).to(device)
		self.qs = torch.zeros((max_len, n_envs) + (n_a,) + a_shape).to(device)
		self.rewards = torch.zeros((max_len, n_envs)).to(device)
		self.dones = torch.zeros((max_len, n_envs)).to(device)

	def __len__(self):
		return self.max_len - self.ptr - 1

	def add(self, obs, a, log_prob, dist, qas, r, dones):
		if self.ptr >= 0:  # left append
			self.obs[self.ptr] = obs
			self.actions[self.ptr] = a
			self.log_probs[self.ptr] = log_prob
			self.dist[self.ptr] = dist
			self.qs[self.ptr] = qas
			self.rewards[self.ptr] = r
			self.dones[self.ptr] = dones
			self.ptr -= 1
		else:
			self.obs[1:] = self.obs[0: -1].clone()
			self.obs[0] = obs
			self.actions[1:] = self.actions[0: -1].clone()
			self.actions[0] = a
			self.log_probs[1:] = self.log_probs[0: -1].clone()
			self.log_probs[0] = log_prob
			self.dist[1:] = self.dist[0: -1].clone()
			self.dist[0] = dist
			self.qs[1:] = self.qs[0: -1].clone()
			self.qs[0] = qas
			self.rewards[1:] = self.rewards[0: -1].clone()
			self.rewards[0] = r
			self.dones[1:] = self.dones[0: -1].clone()
			self.dones[0] = dones

	def sample(self, batch_size):  # sample the most up-to-date sample
		assert batch_size <= self.max_len - self.ptr - 1
		return self.obs[self.ptr + 1: batch_size],\
			   self.actions[self.ptr + 1: batch_size], \
			   self.log_probs[self.ptr + 1: batch_size], \
			   self.dist[self.ptr + 1: batch_size], \
			   self.qs[self.ptr + 1: batch_size], \
			   self.rewards[self.ptr + 1: batch_size], \
			   self.dones[self.ptr + 1: batch_size]

	def reward_backprop(self, env_idx, gamma):
		for ev in range(env_idx):
			for step in range(1, self.max_len):
				if not self.dones[step][ev]:
					self.rewards[step][ev] = gamma * self.rewards[step - 1][ev]
				else:
					break

	def value_bootstrap(self):
		pass

	def clear(self):
		self.obs = torch.zeros((self.max_len, self.n_envs) + self.ob_shape).to(self.device)
		self.actions = torch.zeros((self.max_len, self.n_envs) + self.a_shape).to(self.device)
		self.log_probs = torch.zeros((self.max_len, self.n_envs)).to(self.device)
		self.dist = torch.zeros((self.max_len, self.n_envs) + (self.n_a,) + self.a_shape).to(self.device)
		self.qs = torch.zeros((self.max_len, self.n_envs) + (self.n_a,) + self.a_shape).to(self.device)
		self.rewards = torch.zeros((self.max_len, self.n_envs)).to(self.device)
		self.dones = torch.zeros((self.max_len, self.n_envs)).to(self.device)
		self.ptr = self.max_len - 1  # from right most element


class PPO(nn.Module):
	def __init__(self, ob_dim, width, depth, a_dim, gamma):
		super(PPO, self).__init__()
		self.device = torch.device("cuda") \
			if torch.cuda.is_available() else torch.device("cpu")
		self.gamma = gamma
		self.actor = MLP(
			n_in=ob_dim,
			depth=depth,
			width=width,
			n_out=a_dim
		).to(self.device)

		self.critic = MLP(
			n_in=ob_dim,
			depth=depth,
			width=width,
			n_out=a_dim
		).to(self.device)

	def calc_qs(self, ob):
		# ob = torch.tensor(ob).to(self.device)
		return self.critic(ob)

	def choose_action(self,
	                  ob,
	                  explore=exploration.EGreedy(epsilon=0)):
		logits = self.actor(ob)
		qs = self.critic(ob)
		a = explore(logits)
		others = {
			'qs': qs
		}
		return a, others

	def calc_pi_and_q(self, ob, a=None, explore=exploration.Sample()):
		logits = self.actor(ob)
		probs = Categorical(logits=logits)
		qs = self.critic(ob)
		if a is None:
			a = explore(probs)
		return a, probs.log_prob(a), probs.probs, qs, probs.entropy()

	@staticmethod
	def q2v(qs, dist, dim=(2, 3)):
		v = torch.sum(qs * dist, dim=dim)
		return v

	def play_one_epi(self,
					 env,
					 explore=exploration.EGreedy(epsilon=0),
					 render=False):
		ob, _ = env.reset()
		term = False
		ret = 0
		while not term:
			with torch.no_grad():
				ob = torch.tensor(ob).to(self.device)
				a, _ = self.choose_action(ob, explore=explore)
				ob, r, term, _, _ = env.step(a)
				ret += r
				if render:
					env.render()
		return ret

	def start_train(self,
					lr_actor,
					lr_critic,
					envs,
					test_env,
					update_step,
					batch_size,
					epi_tol,
					update_epo=4,
					norm_adv=False,
					clip_epsilon=0.2,
					qf_coef=0.5,
					ent_coef=0.01,
					max_grad_norm=0.5,
					render=False,
					explore=None):

		replay_buffer = ReplayBuffer(
			max_len=update_step,
			n_envs=envs.num_envs,
			ob_shape=envs.single_observation_space.shape,
			a_shape=envs.single_action_space.shape,
			n_a=envs.single_action_space.n,
			device=self.device
		)
		optimizer_actor = optim.Adam(
			self.actor.parameters(),
			lr=lr_actor,
			eps=1e-5
		)
		optimizer_critic = optim.Adam(
			self.critic.parameters(),
			lr=lr_critic,
			eps=1e-5
		)
		epi_ctr = 0  # how many games have been played in total
		update_ctr = 0
		ob, _ = envs.reset()
		ob = torch.tensor(ob).to(self.device)
		with tqdm.tqdm(total=epi_tol) as pbar:
			while epi_ctr < epi_tol:
				# rollout phase
				for step in range(0, update_step):
					with torch.no_grad():
						a, log_p, dists, q, _ = self.calc_pi_and_q(ob)
						ob_nx, r, done, _, _ = envs.step(a.cpu().numpy())
						ob_nx = torch.tensor(ob_nx).to(self.device)
						r = torch.tensor(r).to(self.device)
						done = torch.tensor(done).to(self.device).to(torch.float)
						replay_buffer.add(ob, a, log_p, dists, q, r, done)
						ob = ob_nx

						num_epi_done = torch.sum(done).item()
						epi_ctr += num_epi_done
						pbar.update(num_epi_done)

				obs, actions, log_ps, dists, qs, rewards, dones = replay_buffer.sample(update_step)
				replay_buffer.clear()

				# update phase
				with torch.no_grad():
					vals = self.q2v(qs, dists, dim=2)
					rets = torch.zeros_like(rewards).to(self.device)
					rets[0] = torch.where(dones[0] > 0, r[0], vals[0])  # if latest sample is not done
					for t in range(0, update_step - 1):
						not_done = 1.0 - dones[t + 1]
						rets[t + 1] = rewards[t + 1] + (not_done * self.gamma * rets[t])
					advs = rets - vals

				acts = actions.cpu().numpy()
				returns = rets.cpu().numpy()
				ds = dones.cpu().numpy()
				rs = rewards.cpu().numpy()
				advas = advs.cpu().numpy()

				# flatten the batch
				flt_obs = obs.reshape((-1,) + envs.single_observation_space.shape)
				flt_actions = actions.reshape((-1,) + envs.single_action_space.shape)
				flt_log_ps = log_ps.reshape(-1)
				flt_advs = advs.reshape(-1)
				flt_rets = rets.reshape(-1)
				flt_r = rewards.reshape(-1)

				flt_inds = np.arange(update_step * envs.num_envs)
				for epo in range(update_epo):
					np.random.shuffle(flt_inds)
					for start in range(0, len(flt_inds), batch_size):
						end = start + batch_size
						b_inds = flt_inds[start: end]

						_, log_ps_new, dists_new, qs_new, entropies = self.calc_pi_and_q(
							ob=flt_obs[b_inds],
							a=flt_actions.long()[b_inds]
						)
						log_ratio = log_ps_new - flt_log_ps[b_inds]
						ratio = log_ratio.exp()

						b_advs = flt_advs[b_inds]
						if norm_adv:
							b_advs = (b_advs - b_advs.mean()) / (b_advs.std() + 1e-8)

						# policy loss
						pg_loss1 = -b_advs * ratio
						pg_loss2 = -b_advs * torch.clamp(ratio, 1 - clip_epsilon, 1 + clip_epsilon)
						pg_loss = torch.max(pg_loss1, pg_loss2).mean()

						# Q(a) loss
						qas_new = qs_new.gather(1, flt_actions.long()[b_inds].reshape(-1, 1)).reshape(-1)
						qa_tgt = flt_rets[b_inds]
						# q_loss = 0.5 * ((qas_new - flt_rets[b_inds] + flt_r[b_inds]) ** 2).mean()
						# q_loss = F.mse_loss(qas_new, qa_tgt)
						q_loss = 0.5 * ((qas_new - qa_tgt.detach()) ** 2).mean()
						# fa = flt_actions.long()[b_inds].reshape(-1, 1).cpu().numpy()
						# qsn = qs_new.detach().cpu().numpy()
						# qasn = qas_new.detach().cpu().numpy()

						# entropy loss
						entropy_loss = entropies.mean()

						loss = pg_loss + (qf_coef * q_loss) - (ent_coef * entropy_loss)

						optimizer_actor.zero_grad()
						optimizer_critic.zero_grad()
						loss.backward()
						nn.utils.clip_grad_norm_(self.actor.parameters(), max_grad_norm)
						nn.utils.clip_grad_norm_(self.critic.parameters(), max_grad_norm)
						optimizer_actor.step()
						optimizer_critic.step()

				# evaluation phase
				update_ctr += 1
				if update_ctr % 100 == 0:
					test_epi = 10
					cumulated_ret = 0
					for ep in range(test_epi):
						cumulated_ret += self.play_one_epi(
							env=test_env,
							explore=exploration.EGreedy(epsilon=0),
							render=render
						)
					pbar.set_postfix({
						'num update': update_ctr,
						'play {} epi avg ret'.format(str(test_epi)): cumulated_ret / test_epi,
					})


NUM_ENVS = 8
if __name__ == '__main__':
	# envs = gym.vector.SyncVectorEnv(
	# 	[lambda: gym.make('CartPole-v1',
	# 	                  render_mode=None) for _ in range(NUM_ENVS)]
	# )
	# test_env = gym.make('CartPole-v1', render_mode='human')
	# agents = PPO(
	# 	ob_dim=4,
	# 	width=256,
	# 	depth=2,
	# 	a_dim=2,
	# 	gamma=0.99)
	#
	# agents.start_train(
	# 	lr_actor=1e-5,
	# 	lr_critic=1e-4,
	# 	envs=envs,
	# 	test_env=test_env,
	# 	update_step=128,
	# 	batch_size=64,
	# 	epi_tol=20000,
	# 	update_epo=4,
	# 	norm_adv=True,
	# 	clip_epsilon=0.2,
	# 	qf_coef=0.5,
	# 	ent_coef=0.01,
	# 	max_grad_norm=0.5,
	# 	render=True,
	# 	explore=None
	# )

	envs = gym.vector.SyncVectorEnv(
		[lambda: gym.make('soccer_offense:soccer_offense/SoccerOffense-v0',
		                  render_mode=None, goalie_mode='chase') for _ in range(NUM_ENVS)]
	)
	test_env = gym.make('soccer_offense:soccer_offense/SoccerOffense-v0',
						render_mode=None, goalie_mode='chase')
	agents = PPO(
		ob_dim=12,
		width=256,
		depth=2,
		a_dim=8,
		gamma=0.99)

	agents.start_train(
		lr_actor=1e-5,
		lr_critic=1e-4,
		envs=envs,
		test_env=test_env,
		update_step=128,
		batch_size=64,
		epi_tol=20000,
		update_epo=4,
		norm_adv=True,
		clip_epsilon=0.2,
		qf_coef=0.5,
		ent_coef=0.01,
		max_grad_norm=0.5,
		render=False,
		explore=None
	)


