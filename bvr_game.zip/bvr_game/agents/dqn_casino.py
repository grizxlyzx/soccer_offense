import numpy as np
import collections
import torch.nn.functional as F
import torch
import random
import gym
import tqdm
import os
import utils.exploration as exploration
from networks.networks import *


# os.environ["CUDA_VISIBLE_DEVICES"] = ""

class ReplayBuffer:
    def __init__(self, capacity):
        self.buffer = collections.deque([], maxlen=capacity)  # 队列,先进先出

    def add(self, state, action, reward, next_state, done, qs, ob_pred):  # 将数据加入buffer
        self.buffer.appendleft(
            [state, action, reward, next_state, done, qs, ob_pred]
        )  # [tn, tn-1, ..., t0, tn, tn-1, ...]

    def sample(self, batch_size):  # 从buffer中采样数据,数量为batch_size
        transitions = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done, qs, ob_pred = zip(*transitions)
        return np.array(state), action, reward, np.array(next_state), done, qs, ob_pred

    def reward_backprop(self, gamma):
        if len(self.buffer) <= 1:
            return
        for i in range(1, len(self.buffer)):
            if not self.buffer[i][4]:  # if NOT term
                self.buffer[i][2] = gamma * self.buffer[i - 1][2]
            else:
                return

    def size(self):  # 目前buffer中数据的数量
        return len(self.buffer)

    def clear(self):
        self.buffer.clear()


class DQN:
    def __init__(self,
        action_dim,
        state_dim,
        depth,
        width,
        gamma=0.9
    ):

        self.action_dim = action_dim
        self.state_dim = state_dim
        self.depth = depth
        self.width = width
        self.gamma = gamma
        self.count = 0
        self.device = torch.device("cuda") \
            if torch.cuda.is_available() else torch.device("cpu")
        self.qob_net = MLP(
            n_in=state_dim + action_dim,
            depth=depth,
            width=width,
            n_out=1 + state_dim
        ).to(self.device)
        self.gamma = gamma

    def choose_action(self, ob, explore=exploration.e_greedy, explore_kwargs=None):
        if explore_kwargs is None:
            explore_kwargs = {'epsilon': 0}
        ob_batch = self.make_ob_batch(ob).to(self.device)
        out = self.qob_net(ob_batch)
        qs = out[:, 0].reshape(-1)
        ob_pred = out[:, 1:]
        a = explore(qs, **explore_kwargs)
        return a, qs, ob_pred

    def make_ob_batch(self, ob):
        ob = torch.tensor(ob).to(self.device)
        ob_batch = torch.zeros([self.action_dim, self.state_dim + self.action_dim]).to(self.device)
        one_hot_actions = F.one_hot(torch.arange(self.action_dim), num_classes=self.action_dim).to(self.device)
        for i, one_hot_a in enumerate(one_hot_actions):
            ob_batch[i] = torch.concat([ob, one_hot_a], dim=0)
        return ob_batch

    def make_b_ob_batch(self, b_ob):
        b_ob_batch = torch.zeros([b_ob.shape[0], self.action_dim, self.state_dim + self.action_dim]).to(self.device)
        one_hot_actions = F.one_hot(torch.arange(self.action_dim), num_classes=self.action_dim).to(self.device)
        for j in range(b_ob.shape[0]):
            ob_batch = torch.zeros([self.action_dim, self.state_dim + self.action_dim]).to(self.device)
            for i, one_hot_a in enumerate(one_hot_actions):
                ob_batch[i] = torch.concat([b_ob[j], one_hot_a], dim=0)
        return b_ob_batch

    def calc_loss(self, ob, a, r, ob_nx, term, qs, ob_pred, tgt_qob_net):
        ob = torch.tensor(ob, dtype=torch.float).to(self.device)
        a = torch.tensor(a, dtype=torch.float).long().to(self.device).view(-1, 1)
        r = torch.tensor(r, dtype=torch.float).to(self.device).view(-1, 1)
        ob_nx = torch.tensor(ob_nx, dtype=torch.float).to(self.device)
        term = torch.tensor(term, dtype=torch.float).to(self.device).view(-1, 1)
        # qs = np.array(qs)
        # qs = torch.tensor(qs, dtype=torch.float).to(self.device)
        # ob_pred = torch.tensor(ob_pred, dtype=torch.float).to(self.device)

        b_ob_batch = self.make_b_ob_batch(ob)
        raw = self.qob_net(b_ob_batch)
        b_qs_pred = raw[:, :, 0]
        b_ob_pred = raw[:, :, 1:]
        b_q_a = b_qs_pred.gather(1, a)

        b_ob_batch_nx = self.make_b_ob_batch(ob_nx).to(self.device)
        raw = tgt_qob_net(b_ob_batch_nx).detach()
        b_qs_pred_nx = raw[:, :, 0]
        # b_ob_nx_pred = raw[:, :, 1:]
        max_q_a_nx = b_qs_pred_nx.max(1)[0].view(-1, 1)
        q_tgt = r + self.gamma * max_q_a_nx * (1 - term)
        q_loss = F.mse_loss(b_q_a, q_tgt)
        ob_nx_pred_a = b_ob_pred[torch.arange(len(b_ob_pred)), a.view(-1)]
        # ob_nx_pred_a = b_ob_pred.gather(dim=1, index=a.view(-1))
        ob_loss = F.mse_loss(ob_nx_pred_a, ob_nx)

        loss = q_loss + ob_loss
        return loss

    def train(self,
              env,
              lr,
              buffer_size,
              batch_size,
              tgt_update,
              num_episode,
              explore,
              explore_kwargs):

        tgt_qob_net = MLP(
            n_in=self.state_dim + self.action_dim,
            depth=self.depth,
            width=self.width,
            n_out=1 + self.state_dim
        ).to(self.device)
        optimizer = torch.optim.Adam(self.qob_net.parameters(), lr=lr)
        replay_buffer = ReplayBuffer(buffer_size)
        step_ctr = 0
        test_epi = 500
        with tqdm.tqdm(total=num_episode) as pbar:
            last_n_epi_ret = np.zeros(test_epi)
            for epi in range(num_episode):
                epi_ret = 0
                ob, _ = env.reset()
                term = False
                while not term:
                    a, qs, ob_pred = self.choose_action(ob, explore=explore,
                                                        explore_kwargs=explore_kwargs)
                    ob_nx, r, term, _, _ = env.step(a)
                    replay_buffer.add(ob, a, r, ob_nx, term, qs.detach().cpu().numpy(), ob_pred.detach().cpu().numpy())
                    # if term:
                    #     replay_buffer.reward_backprop(self.gamma)
                    ob = ob_nx
                    epi_ret += r
                    if replay_buffer.size() > batch_size:
                        b_ob, b_a, b_r, b_ob_nx, b_term, b_qs, b_ob_pred = replay_buffer.sample(batch_size)
                        loss = self.calc_loss(b_ob, b_a, b_r, b_ob_nx, b_term, b_qs, b_ob_pred, tgt_qob_net)
                        optimizer.zero_grad()
                        loss.backward()
                        optimizer.step()

                        if step_ctr % tgt_update == 0:
                            tgt_qob_net.load_state_dict(self.qob_net.state_dict())
                        step_ctr += 1
                last_n_epi_ret[1:] = last_n_epi_ret[0: -1]
                last_n_epi_ret[0] = epi_ret
                pbar.set_postfix({'<last 500 epi avg ret>': last_n_epi_ret.mean()})
                pbar.update(1)

                rec.append(last_n_epi_ret)

    def play_one_epi(self, env):
        ob, _ = env.reset()
        term = False
        ret = 0
        while not term:
            a, _, _ = self.choose_action(ob, explore=exploration.e_greedy, explore_kwargs={'epsilon': 0})  # greedy
            ob, r, term, _, _ = env.step(a)
            ret += r
            env.render()
        return ret

def evaluation(env, agent, epi):
    R_total = 0
    for _ in tqdm.tqdm(range(epi)):
        R_total += agent.play_one_epi(env)
    return R_total / epi




if __name__ == '__main__':
    rec = []
    env = gym.make('soccer_offense:soccer_offense/SoccerOffense-v0',
                   render_mode=None, goalie_mode='chase')

    agent = DQN(action_dim=8, state_dim=12, depth=2, width=256,
                gamma=0.9)

    agent.train(
        env=env,
        lr=1e-4,
        buffer_size=3000,
        batch_size=2048,
        tgt_update=10,
        num_episode=20000,
        explore=exploration.EGreedy(epsilon=0.1),
        explore_kwargs={}
    )
    rec = np.array(rec)
    evl = evaluation(env, agent, 500)
    np.savetxt('./e_greedy_casino({:.2f}).txt'.format(evl), rec, delimiter=',')


    # rec = []
    # agent = DQN(action_dim=8, state_dim=14, depth=2, width=256,
    #             gamma=0.9)
    #
    # agent.train(
    #     env=env,
    #     lr=1e-4,
    #     buffer_size=3000,
    #     batch_size=2048,
    #     tgt_update=10,
    #     num_episode=20000,
    #     explore=exploration.RNDUCT(
    #         state_dim=14,
    #         lr=1e-4,
    #         env=env
    #     ),
    #     explore_kwargs={}
    # )
    #
    # rec = np.array(rec)
    # evl = evaluation(env, agent, 500)
    # np.savetxt('./rnduct({:.2f}).txt'.format(evl), rec, delimiter=',')
