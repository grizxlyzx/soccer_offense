import numpy as np
import torch
from torch import nn
from torch import optim
import torch.nn.functional as F
import collections
from open_spiel.python.pytorch.losses import rl_losses
from open_spiel.python.pytorch.dqn import SonnetLinear
import gym
import games.gym_bvr.gym_bvr.envs as gym_bvr


env = gym.make("PyBVR2D-v0")
env.reset()
done = False
while not done:
    action = env.action_space.sample()
    _, _, done, _, info = env.step(action)
    env.render()
print(info)


