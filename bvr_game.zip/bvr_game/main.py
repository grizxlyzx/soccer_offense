import gym
import numpy as np

env = gym.make('soccer_offense:soccer_offense/SoccerOffense-v0', render_mode='human', goalie_mode='chase')
# s, _ = env.reset()
# env.play()
sd = None
env.reset()
for i in range(1000):
    a = env.action_space.sample()
    s, a, t, _, _ = env.step(a)
    print(env.step_ctr)
    if env.step_ctr == 10:
        sd = env.get_state_dict()
        print('saved')
    # if t and (sd is not None):
    if env.step_ctr == 20:
        env.load_state_dict(sd)
        print('loaded')
    env.render()

