import gym
import numpy as np
import torch
from torch.distributions.categorical import Categorical
import torch.nn.functional as F

a = torch.zeros([1,2,3])
a = torch.arange(3)
b = torch.arange(4)
c = torch.concat([a, b], dim=0)
a = F.one_hot(torch.arange(5), num_classes=5)
for i in a:

    print()








envs = gym.vector.SyncVectorEnv(
    [lambda: gym.make('soccer_offense:soccer_offense/SoccerOffense-v0',
                      render_mode=None, goalie_mode='chase') for _ in range(4)]
)




a = envs.single_action_space.n

envs = gym.vector.SyncVectorEnv(
    [lambda: gym.make('CartPole-v1', render_mode=None) for _ in range(6)]
)
a = envs.single_action_space.shape
ob, _ = envs.reset()
for i in range(1000):
    a = np.array([1, 1])
    ob_nx, r, done, _, _ = envs.step(a)
    print(done, r)
