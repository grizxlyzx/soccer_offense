import numpy as np
import collections
import matplotlib.pyplot as plt

if __name__ == '__main__':
    egreedy_rec = np.loadtxt('/home/zx/projs/bvr_game/agents/e_greedy(53.74).txt', delimiter=',')
    rndutc = np.loadtxt('/home/zx/projs/bvr_game/agents/rnduct(90.87).txt', delimiter=',')
    egreedy_pure_td = np.loadtxt('/home/zx/projs/bvr_game/agents/e_greedy35.68.txt', delimiter=',')
    plt.plot(egreedy_rec, )
    plt.plot(rndutc, )
    plt.plot(egreedy_pure_td)
    plt.show()