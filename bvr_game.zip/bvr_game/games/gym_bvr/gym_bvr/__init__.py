from gym.envs.registration import register

register(
    id="PyBVR2D-v0",
    entry_point="gym_bvr.envs:BVR2D",
    # max_episode_steps=2000,
)
