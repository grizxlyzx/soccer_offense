#include "missileXX15.h"
#include "missileXX15_private.h"

real_T look1_binlxpw(real_T u0, const real_T bp0[], const real_T table[],
                     uint32_T maxIndex)
{
  real_T frac;
  real_T yL_0d0;
  uint32_T iLeft;
  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac = (u0 - bp0[0U]) / (bp0[1U] - bp0[0U]);
  } else if (u0 < bp0[maxIndex]) {
    uint32_T bpIdx;
    uint32_T iRght;
    bpIdx = maxIndex >> 1U;
    iLeft = 0U;
    iRght = maxIndex;
    while (iRght - iLeft > 1U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1U;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1U] - bp0[iLeft]);
  } else {
    iLeft = maxIndex - 1U;
    frac = (u0 - bp0[maxIndex - 1U]) / (bp0[maxIndex] - bp0[maxIndex - 1U]);
  }

  yL_0d0 = table[iLeft];
  return (table[iLeft + 1U] - yL_0d0) * frac + yL_0d0;
}

void missileXX15ModelClass::rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew { rtsiGetSolverStopTime(si) };

  time_T h { rtsiGetStepSize(si) };

  real_T *x { rtsiGetContStates(si) };

  ODE1_IntgData *id { static_cast<ODE1_IntgData *>(rtsiGetSolverData(si)) };

  real_T *f0 { id->f[0] };

  int_T i;
  int_T nXc { 12 };

  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  missileXX15_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; ++i) {
    x[i] += h * f0[i];
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  if (std::isnan(u0) || std::isnan(u1)) {
    y = (rtNaN);
  } else if (std::isinf(u0) && std::isinf(u1)) {
    int32_T u0_0;
    int32_T u1_0;
    if (u0 > 0.0) {
      u0_0 = 1;
    } else {
      u0_0 = -1;
    }

    if (u1 > 0.0) {
      u1_0 = 1;
    } else {
      u1_0 = -1;
    }

    y = std::atan2(static_cast<real_T>(u0_0), static_cast<real_T>(u1_0));
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = std::atan2(u0, u1);
  }

  return y;
}

real_T rt_powd_snf(real_T u0, real_T u1)
{
  real_T y;
  if (std::isnan(u0) || std::isnan(u1)) {
    y = (rtNaN);
  } else {
    real_T tmp;
    real_T tmp_0;
    tmp = std::abs(u0);
    tmp_0 = std::abs(u1);
    if (std::isinf(u1)) {
      if (tmp == 1.0) {
        y = 1.0;
      } else if (tmp > 1.0) {
        if (u1 > 0.0) {
          y = (rtInf);
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = (rtInf);
      }
    } else if (tmp_0 == 0.0) {
      y = 1.0;
    } else if (tmp_0 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = std::sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > std::floor(u1))) {
      y = (rtNaN);
    } else {
      y = std::pow(u0, u1);
    }
  }

  return y;
}

void missileXX15ModelClass::step()
{
  if (rtmIsMajorTimeStep((&missileXX15_M))) {
    rtsiSetSolverStopTime(&(&missileXX15_M)->solverInfo,(((&missileXX15_M)
      ->Timing.clockTick0+1)*(&missileXX15_M)->Timing.stepSize0));
  }

  if (rtmIsMinorTimeStep((&missileXX15_M))) {
    (&missileXX15_M)->Timing.t[0] = rtsiGetT(&(&missileXX15_M)->solverInfo);
  }

  {
    static const int8_T d_0[3]{ 0, 0, 1 };

    real_T b_0[9];
    real_T rtb_Product9_tmp_0[9];
    real_T rtb_Product9_tmp_1[9];
    real_T rtb_Add[3];
    real_T rtb_Product9[3];
    real_T rtb_Product9_tmp[3];
    real_T Gain1_idx_1;
    real_T d;
    real_T rtb_Abs;
    real_T rtb_Add7;
    real_T rtb_Product9_tmp_tmp;
    real_T rtb_Product9_tmp_tmp_0;
    real_T rtb_Product9_tmp_tmp_1;
    real_T rtb_Product9_tmp_tmp_2;
    real_T rtb_Sign;
    real_T rtb_Switch8_l;
    real_T rtb_omegax;
    real_T rtb_omegaz;
    real_T rtb_vxr;
    real_T rtb_vzr;
    real_T *lastU;
    int32_T b_tmp;
    int32_T i;
    int32_T i_0;
    int8_T Y_tmp[9];
    int8_T Y_tmp_0[9];
    int8_T b[9];
    boolean_T Compare;
    Gain1_idx_1 = 0.017453292519943295 * missileXX15_U.Euler0[1];
    if (rtmIsMajorTimeStep((&missileXX15_M))) {
      b[1] = 0;
      b[4] = 1;
      b[7] = 0;
      b[2] = 0;
      b[5] = 0;
      b[8] = 1;
      Y_tmp[0] = 1;
      Y_tmp[3] = 0;
      Y_tmp[6] = 0;
      b[0] = 1;
      Y_tmp[1] = 0;
      b[3] = 0;
      Y_tmp[4] = 1;
      b[6] = 0;
      Y_tmp[7] = 0;
      Y_tmp[2] = 0;
      Y_tmp[5] = 0;
      Y_tmp[8] = 1;
      Y_tmp_0[0] = 1;
      Y_tmp_0[3] = 0;
      Y_tmp_0[6] = 0;
      Y_tmp_0[1] = 0;
      Y_tmp_0[4] = 1;
      Y_tmp_0[7] = 0;
      for (i = 0; i < 3; i++) {
        for (i_0 = 0; i_0 < 3; i_0++) {
          b_tmp = 3 * i_0 + i;
          b_0[b_tmp] = 0.0;
          b_0[b_tmp] += static_cast<real_T>(Y_tmp[3 * i_0] * b[i]);
          b_0[b_tmp] += static_cast<real_T>(Y_tmp[3 * i_0 + 1] * b[i + 3]);
          b_0[b_tmp] += static_cast<real_T>(Y_tmp[3 * i_0 + 2] * b[i + 6]);
        }

        Y_tmp_0[3 * i + 2] = d_0[i];
      }

      for (i = 0; i < 3; i++) {
        for (i_0 = 0; i_0 <= 0; i_0 += 2) {
          __m128d tmp;
          __m128d tmp_0;
          b_tmp = 3 * i + i_0;
          _mm_storeu_pd(&missileXX15_B.Y[b_tmp], _mm_set1_pd(0.0));
          tmp = _mm_loadu_pd(&b_0[i_0]);
          tmp_0 = _mm_loadu_pd(&missileXX15_B.Y[b_tmp]);
          _mm_storeu_pd(&missileXX15_B.Y[b_tmp], _mm_add_pd(tmp_0, _mm_mul_pd
            (_mm_set1_pd(static_cast<real_T>(Y_tmp_0[3 * i])), tmp)));
          tmp = _mm_loadu_pd(&b_0[i_0 + 3]);
          tmp_0 = _mm_loadu_pd(&missileXX15_B.Y[b_tmp]);
          _mm_storeu_pd(&missileXX15_B.Y[b_tmp], _mm_add_pd(_mm_mul_pd
            (_mm_set1_pd(static_cast<real_T>(Y_tmp_0[3 * i + 1])), tmp), tmp_0));
          tmp = _mm_loadu_pd(&b_0[i_0 + 6]);
          tmp_0 = _mm_loadu_pd(&missileXX15_B.Y[b_tmp]);
          _mm_storeu_pd(&missileXX15_B.Y[b_tmp], _mm_add_pd(_mm_mul_pd
            (_mm_set1_pd(static_cast<real_T>(Y_tmp_0[3 * i + 2])), tmp), tmp_0));
        }

        for (i_0 = 2; i_0 < 3; i_0++) {
          b_tmp = 3 * i + i_0;
          missileXX15_B.Y[b_tmp] = 0.0;
          missileXX15_B.Y[b_tmp] += static_cast<real_T>(Y_tmp_0[3 * i]) *
            b_0[i_0];
          missileXX15_B.Y[b_tmp] += static_cast<real_T>(Y_tmp_0[3 * i + 1]) *
            b_0[i_0 + 3];
          missileXX15_B.Y[b_tmp] += static_cast<real_T>(Y_tmp_0[3 * i + 2]) *
            b_0[i_0 + 6];
        }
      }
    }

    if (missileXX15_DW.Integrator6_IWORK != 0) {
      missileXX15_X.Integrator6_CSTATE = 0.017453292519943295 *
        missileXX15_U.Euler0[2];
    }

    if (missileXX15_DW._IWORK != 0) {
      missileXX15_X._CSTATE = Gain1_idx_1;
    }

    if (missileXX15_DW.Integrator1_IWORK != 0) {
      missileXX15_X.Integrator1_CSTATE[0] = missileXX15_U.XYZ0[0];
      missileXX15_X.Integrator1_CSTATE[1] = missileXX15_U.XYZ0[1];
      missileXX15_X.Integrator1_CSTATE[2] = missileXX15_U.XYZ0[2];
    }

    rtb_Product9_tmp_tmp_2 = std::sin(missileXX15_X._CSTATE);
    rtb_Product9_tmp_tmp_1 = std::cos(missileXX15_X._CSTATE);
    rtb_Product9_tmp_tmp = std::sin(missileXX15_X.Integrator6_CSTATE);
    rtb_Product9_tmp_tmp_0 = std::cos(missileXX15_X.Integrator6_CSTATE);
    b[1] = 0;
    b[4] = 1;
    b[7] = 0;
    b[2] = 0;
    b[5] = 0;
    b[8] = 1;
    rtb_Product9_tmp_0[0] = rtb_Product9_tmp_tmp_1;
    rtb_Product9_tmp_0[3] = 0.0;
    rtb_Product9_tmp_0[6] = -rtb_Product9_tmp_tmp_2;
    rtb_Product9_tmp[0] = missileXX15_U.XYZT[0] -
      missileXX15_X.Integrator1_CSTATE[0];
    b[0] = 1;
    rtb_Product9_tmp_0[1] = 0.0;
    rtb_Product9_tmp[1] = missileXX15_U.XYZT[1] -
      missileXX15_X.Integrator1_CSTATE[1];
    b[3] = 0;
    rtb_Product9_tmp_0[4] = 1.0;
    rtb_Product9_tmp[2] = missileXX15_U.XYZT[2] -
      missileXX15_X.Integrator1_CSTATE[2];
    b[6] = 0;
    rtb_Product9_tmp_0[7] = 0.0;
    rtb_Product9_tmp_0[2] = rtb_Product9_tmp_tmp_2;
    rtb_Product9_tmp_0[5] = 0.0;
    rtb_Product9_tmp_0[8] = rtb_Product9_tmp_tmp_1;
    rtb_Product9_tmp_1[0] = rtb_Product9_tmp_tmp_0;
    rtb_Product9_tmp_1[3] = rtb_Product9_tmp_tmp;
    rtb_Product9_tmp_1[6] = 0.0;
    rtb_Product9_tmp_1[1] = -rtb_Product9_tmp_tmp;
    rtb_Product9_tmp_1[4] = rtb_Product9_tmp_tmp_0;
    rtb_Product9_tmp_1[7] = 0.0;
    for (i = 0; i < 3; i++) {
      for (i_0 = 0; i_0 < 3; i_0++) {
        b_tmp = 3 * i_0 + i;
        b_0[b_tmp] = 0.0;
        b_0[b_tmp] += rtb_Product9_tmp_0[3 * i_0] * static_cast<real_T>(b[i]);
        b_0[b_tmp] += rtb_Product9_tmp_0[3 * i_0 + 1] * static_cast<real_T>(b[i
          + 3]);
        b_0[b_tmp] += rtb_Product9_tmp_0[3 * i_0 + 2] * static_cast<real_T>(b[i
          + 6]);
      }

      rtb_Product9_tmp_1[3 * i + 2] = d_0[i];
    }

    for (i = 0; i < 3; i++) {
      rtb_Product9[i] = 0.0;
      rtb_Add[i] = 0.0;
      for (i_0 = 0; i_0 < 3; i_0++) {
        rtb_Switch8_l = rtb_Product9_tmp[i_0];
        b_tmp = 3 * i_0 + i;
        rtb_Product9_tmp_0[b_tmp] = 0.0;
        rtb_Product9_tmp_0[b_tmp] += rtb_Product9_tmp_1[3 * i_0] * b_0[i];
        rtb_Product9_tmp_0[b_tmp] += rtb_Product9_tmp_1[3 * i_0 + 1] * b_0[i + 3];
        rtb_Product9_tmp_0[b_tmp] += rtb_Product9_tmp_1[3 * i_0 + 2] * b_0[i + 6];
        rtb_Product9[i] += rtb_Product9_tmp_0[b_tmp] * rtb_Switch8_l;
        rtb_Add[i] += missileXX15_B.Y[b_tmp] * rtb_Switch8_l;
      }
    }

    if (missileXX15_DW.Integrator_IWORK != 0) {
      missileXX15_X.Integrator_CSTATE[0] = missileXX15_U.Vxyz0[0];
      missileXX15_X.Integrator_CSTATE[1] = missileXX15_U.Vxyz0[1];
      missileXX15_X.Integrator_CSTATE[2] = missileXX15_U.Vxyz0[2];
    }

    missileXX15_B.Integrator[0] = missileXX15_X.Integrator_CSTATE[0];
    missileXX15_B.Integrator[1] = missileXX15_X.Integrator_CSTATE[1];
    missileXX15_B.Integrator[2] = missileXX15_X.Integrator_CSTATE[2];
    rtb_vzr = missileXX15_B.Integrator[2] - missileXX15_U.VxyzT[2];
    rtb_Switch8_l = missileXX15_B.Integrator[1] - missileXX15_U.VxyzT[1];
    rtb_Add7 = ((0.0 - rtb_Add[0]) * (0.0 - rtb_Add[0]) + (0.0 - rtb_Add[1]) *
                (0.0 - rtb_Add[1])) + (0.0 - rtb_Add[2]) * (0.0 - rtb_Add[2]);
    rtb_omegax = ((0.0 - rtb_Add[1]) * rtb_vzr - (0.0 - rtb_Add[2]) *
                  rtb_Switch8_l) / rtb_Add7;
    rtb_vxr = missileXX15_B.Integrator[0] - missileXX15_U.VxyzT[0];
    rtb_omegaz = ((0.0 - rtb_Add[0]) * rtb_Switch8_l - (0.0 - rtb_Add[1]) *
                  rtb_vxr) / rtb_Add7;
    rtb_Abs = std::abs((((0.0 - rtb_Add[0]) * rtb_vxr + (0.0 - rtb_Add[1]) *
                         rtb_Switch8_l) + (0.0 - rtb_Add[2]) * rtb_vzr) / std::
                       sqrt(rtb_Add7));
    if (rtb_Add[0] < 0.0) {
      rtb_Sign = -1.0;
    } else if (rtb_Add[0] > 0.0) {
      rtb_Sign = 1.0;
    } else if (rtb_Add[0] == 0.0) {
      rtb_Sign = 0.0;
    } else {
      rtb_Sign = (rtNaN);
    }

    if (missileXX15_X.Integrator_CSTATE_m >= 200.0) {
      missileXX15_X.Integrator_CSTATE_m = 200.0;
    } else if (missileXX15_X.Integrator_CSTATE_m <= 0.0) {
      missileXX15_X.Integrator_CSTATE_m = 0.0;
    }

    if (missileXX15_X.Integrator_CSTATE_m > 1.0) {
      if (missileXX15_X.Integrator_CSTATE_m >= 3.0) {
        rtb_Switch8_l = rt_atan2d_snf(rtb_Product9[1], rtb_Product9[0]);
        if (std::abs(57.295779513082323 * rtb_Switch8_l) <= 70.0) {
          d = (rtb_Product9_tmp_tmp * rtb_omegax + rtb_Product9_tmp_tmp_0 *
               rtb_omegaz) * 3.5 * rtb_Abs;
          if (d > 350.0) {
            d = 350.0;
          } else if (d < -350.0) {
            d = -350.0;
          }

          rtb_Switch8_l = d * rtb_Sign;
        } else {
          if (rtb_Switch8_l < 0.0) {
            rtb_Switch8_l = -1.0;
          } else if (rtb_Switch8_l > 0.0) {
            rtb_Switch8_l = 1.0;
          } else if (rtb_Switch8_l == 0.0) {
            rtb_Switch8_l = 0.0;
          } else {
            rtb_Switch8_l = (rtNaN);
          }

          rtb_Switch8_l *= 350.0;
        }
      } else {
        rtb_Switch8_l = 0.0;
      }
    } else {
      rtb_Switch8_l = 0.0;
    }

    Compare = (missileXX15_X.Integrator_CSTATE_m > 0.0);
    if (rtmIsMajorTimeStep((&missileXX15_M)) && rtmIsMajorTimeStep
        ((&missileXX15_M))) {
      if (Compare && (missileXX15_PrevZCX.SampleandHold_Trig_ZCE != 1)) {
        missileXX15_B.In = Gain1_idx_1;
      }

      missileXX15_PrevZCX.SampleandHold_Trig_ZCE = Compare;
    }

    missileXX15_Y.distance = std::sqrt((rtb_Add[0] * rtb_Add[0] + rtb_Add[1] *
      rtb_Add[1]) + rtb_Add[2] * rtb_Add[2]);
    if (missileXX15_Y.distance > 40000.0) {
      if (-missileXX15_X.Integrator1_CSTATE[2] < 27000.0) {
        if (missileXX15_B.In > 0.0) {
          d = (missileXX15_Y.distance - 30000.0) / 1500.0;
        } else {
          d = 0.0;
        }
      } else {
        d = 0.0;
      }
    } else {
      d = 0.0;
    }

    if (missileXX15_X.Integrator_CSTATE_m > 0.5) {
      if (missileXX15_X.Integrator_CSTATE_m > 2.0) {
        if (d > 30.0) {
          d = 30.0;
        }

        if (missileXX15_X.Integrator_CSTATE_m >= d) {
          d = rt_atan2d_snf(-rtb_Product9[2], rtb_Product9[0]);
          if (std::abs(57.295779513082323 * d) <= 70.0) {
            d = ((((0.0 - rtb_Add[2]) * rtb_vxr - (0.0 - rtb_Add[0]) * rtb_vzr) /
                  rtb_Add7 * rtb_Product9_tmp_tmp_1 - rtb_Product9_tmp_tmp_2 *
                  rtb_Product9_tmp_tmp_0 * rtb_omegax) + rtb_Product9_tmp_tmp_2 *
                 rtb_Product9_tmp_tmp * rtb_omegaz) * 3.5 * rtb_Abs;
            if (d > 350.0) {
              d = 350.0;
            } else if (d < -350.0) {
              d = -350.0;
            }

            Gain1_idx_1 = d * rtb_Sign;
          } else {
            if (d < 0.0) {
              d = -1.0;
            } else if (d > 0.0) {
              d = 1.0;
            } else if (d == 0.0) {
              d = 0.0;
            } else {
              d = (rtNaN);
            }

            Gain1_idx_1 = 350.0 * d;
          }
        } else {
          Gain1_idx_1 = 0.0;
        }
      } else if ((Gain1_idx_1 < 0.52539404553415059) && (Gain1_idx_1 >
                  -0.52539404553415059)) {
        d = 57.295779513082323 * Gain1_idx_1;
        if (d > 30.0) {
          d = 30.0;
        } else if (d < 0.0) {
          d = 0.0;
        }

        Gain1_idx_1 = 30.0 - d;
      } else {
        Gain1_idx_1 = 0.0;
      }
    } else {
      Gain1_idx_1 = rtb_Product9_tmp_tmp_1 * -9.8;
    }

    if (-missileXX15_X.Integrator1_CSTATE[2] > 11000.0) {
      rtb_Add7 = 11000.0;
    } else if (-missileXX15_X.Integrator1_CSTATE[2] < 0.0) {
      rtb_Add7 = 0.0;
    } else {
      rtb_Add7 = -missileXX15_X.Integrator1_CSTATE[2];
    }

    rtb_omegax = 288.15 - 0.0065 * rtb_Add7;
    d = std::sqrt((missileXX15_B.Integrator[0] * missileXX15_B.Integrator[0] +
                   missileXX15_B.Integrator[1] * missileXX15_B.Integrator[1]) +
                  missileXX15_B.Integrator[2] * missileXX15_B.Integrator[2]);
    rtb_vzr = (d + 2.2204460492503131E-16) / std::sqrt(401.87433999999996 *
      rtb_omegax);
    missileXX15_B.V_m = d + 2.2204460492503131E-16;
    d = 0.00347041471455839 * rtb_omegax;
    if (11000.0 - (-missileXX15_X.Integrator1_CSTATE[2]) > 0.0) {
      rtb_Add7 = 0.0;
    } else if (11000.0 - (-missileXX15_X.Integrator1_CSTATE[2]) < -9000.0) {
      rtb_Add7 = -9000.0;
    } else {
      rtb_Add7 = 11000.0 - (-missileXX15_X.Integrator1_CSTATE[2]);
    }

    rtb_Add7 = rt_powd_snf(d, 5.2558756014667134) / d * 1.225 * std::exp(1.0 /
      rtb_omegax * (0.034163191409533639 * rtb_Add7));
    Compare = (rtb_vzr >= 5.5);
    if (rtmIsMajorTimeStep((&missileXX15_M)) && rtmIsMajorTimeStep
        ((&missileXX15_M))) {
      missileXX15_B.In_p = ((Compare &&
        (missileXX15_PrevZCX.SampleandHold_Trig_ZCE_a != 1)) ||
                            missileXX15_B.In_p);
      missileXX15_PrevZCX.SampleandHold_Trig_ZCE_a = Compare;
    }

    if (missileXX15_X.Integrator_CSTATE_e >= 200.0) {
      missileXX15_X.Integrator_CSTATE_e = 200.0;
    } else if (missileXX15_X.Integrator_CSTATE_e <= 0.0) {
      missileXX15_X.Integrator_CSTATE_e = 0.0;
    }

    if (missileXX15_X.Integrator_CSTATE_mt >= 200.0) {
      missileXX15_X.Integrator_CSTATE_mt = 200.0;
    } else if (missileXX15_X.Integrator_CSTATE_mt <= 0.0) {
      missileXX15_X.Integrator_CSTATE_mt = 0.0;
    }

    rtb_omegax = missileXX15_B.V_m * missileXX15_B.V_m;
    rtb_vxr = std::sqrt(rtb_Switch8_l * rtb_Switch8_l + Gain1_idx_1 *
                        Gain1_idx_1) * 240.0 / (rtb_omegax * rtb_Add7 * 0.2);
    d = look1_binlxpw(rtb_vzr, missileXX15_ConstP.uDLookupTable1_bp01Data,
                      missileXX15_ConstP.uDLookupTable1_tableData, 1U) - 0.19;
    if (missileXX15_B.In_p) {
      i = 0;
    } else if (missileXX15_X.Integrator_CSTATE_e >= 20.0) {
      i = 0;
    } else {
      i = 22000;
    }

    if (d > 1.0) {
      d = 1.0;
    } else if (d < 0.005) {
      d = 0.005;
    }

    d = (static_cast<real_T>(i) - (look1_binlxpw(rtb_vzr,
           missileXX15_ConstP.uDLookupTable2_bp01Data,
           missileXX15_ConstP.uDLookupTable2_tableData, 6U) * 2.0 * (rtb_vxr *
           rtb_vxr) + d) * 0.5 * rtb_Add7 * 0.2 * rtb_omegax) / 120.0;
    rtb_vzr = Gain1_idx_1 * rtb_Product9_tmp_tmp_2;
    rtb_Add7 = d * rtb_Product9_tmp_tmp_1;
    missileXX15_B.TmpSignalConversionAtIntegrator[0] = (rtb_Add7 *
      rtb_Product9_tmp_tmp_0 - rtb_Switch8_l * rtb_Product9_tmp_tmp) - rtb_vzr *
      rtb_Product9_tmp_tmp_0;
    missileXX15_B.TmpSignalConversionAtIntegrator[1] = (rtb_Add7 *
      rtb_Product9_tmp_tmp + rtb_Switch8_l * rtb_Product9_tmp_tmp_0) - rtb_vzr *
      rtb_Product9_tmp_tmp;
    missileXX15_B.TmpSignalConversionAtIntegrator[2] = -(d *
      rtb_Product9_tmp_tmp_2 + Gain1_idx_1 * rtb_Product9_tmp_tmp_1);
    missileXX15_B.Thetadot_m = (Gain1_idx_1 - 0.0 * rtb_Product9_tmp_tmp_1) /
      missileXX15_B.V_m;
    rtb_Add7 = (&missileXX15_M)->Timing.t[0];
    if ((missileXX15_DW.TimeStampA >= rtb_Add7) && (missileXX15_DW.TimeStampB >=
         rtb_Add7)) {
      d = 0.0;
    } else {
      rtb_Product9_tmp_tmp_2 = missileXX15_DW.TimeStampA;
      lastU = &missileXX15_DW.LastUAtTimeA;
      if (missileXX15_DW.TimeStampA < missileXX15_DW.TimeStampB) {
        if (missileXX15_DW.TimeStampB < rtb_Add7) {
          rtb_Product9_tmp_tmp_2 = missileXX15_DW.TimeStampB;
          lastU = &missileXX15_DW.LastUAtTimeB;
        }
      } else if (missileXX15_DW.TimeStampA >= rtb_Add7) {
        rtb_Product9_tmp_tmp_2 = missileXX15_DW.TimeStampB;
        lastU = &missileXX15_DW.LastUAtTimeB;
      }

      d = (missileXX15_B.V_m - *lastU) / (rtb_Add7 - rtb_Product9_tmp_tmp_2);
    }

    missileXX15_Y.Hit = (missileXX15_Y.distance <= 600.0);
    if (missileXX15_X.Integrator_CSTATE_g >= 200.0) {
      missileXX15_X.Integrator_CSTATE_g = 200.0;
    } else if (missileXX15_X.Integrator_CSTATE_g <= 0.0) {
      missileXX15_X.Integrator_CSTATE_g = 0.0;
    }

    if (missileXX15_X._CSTATE == 1.5707963267948966) {
      missileXX15_B.Psidot_m = 0.0;
    } else {
      missileXX15_B.Psidot_m = rtb_Switch8_l / (missileXX15_B.V_m *
        rtb_Product9_tmp_tmp_1);
    }

    missileXX15_Y.XYZ[0] = missileXX15_X.Integrator1_CSTATE[0];
    missileXX15_Y.Vxyz[0] = missileXX15_B.Integrator[0];
    missileXX15_Y.XYZ[1] = missileXX15_X.Integrator1_CSTATE[1];
    missileXX15_Y.Vxyz[1] = missileXX15_B.Integrator[1];
    missileXX15_Y.XYZ[2] = missileXX15_X.Integrator1_CSTATE[2];
    missileXX15_Y.Vxyz[2] = missileXX15_B.Integrator[2];
    missileXX15_Y.Euler[0] = 0.0;
    missileXX15_Y.Euler[1] = missileXX15_X._CSTATE;
    missileXX15_Y.Euler[2] = missileXX15_X.Integrator6_CSTATE;
    missileXX15_Y.Stop = (missileXX15_Y.Hit || ((d < 0.0) && (missileXX15_B.V_m <=
      450.0)) || (missileXX15_X.Integrator_CSTATE_g > 140.0) ||
                          (-missileXX15_X.Integrator1_CSTATE[2] <=
      missileXX15_U.H0));
  }

  if (rtmIsMajorTimeStep((&missileXX15_M))) {
    real_T *lastU;
    missileXX15_DW.Integrator6_IWORK = 0;
    missileXX15_DW._IWORK = 0;
    missileXX15_DW.Integrator1_IWORK = 0;
    missileXX15_DW.Integrator_IWORK = 0;
    if (missileXX15_DW.TimeStampA == (rtInf)) {
      missileXX15_DW.TimeStampA = (&missileXX15_M)->Timing.t[0];
      lastU = &missileXX15_DW.LastUAtTimeA;
    } else if (missileXX15_DW.TimeStampB == (rtInf)) {
      missileXX15_DW.TimeStampB = (&missileXX15_M)->Timing.t[0];
      lastU = &missileXX15_DW.LastUAtTimeB;
    } else if (missileXX15_DW.TimeStampA < missileXX15_DW.TimeStampB) {
      missileXX15_DW.TimeStampA = (&missileXX15_M)->Timing.t[0];
      lastU = &missileXX15_DW.LastUAtTimeA;
    } else {
      missileXX15_DW.TimeStampB = (&missileXX15_M)->Timing.t[0];
      lastU = &missileXX15_DW.LastUAtTimeB;
    }

    *lastU = missileXX15_B.V_m;
  }

  if (rtmIsMajorTimeStep((&missileXX15_M))) {
    rt_ertODEUpdateContinuousStates(&(&missileXX15_M)->solverInfo);
    ++(&missileXX15_M)->Timing.clockTick0;
    (&missileXX15_M)->Timing.t[0] = rtsiGetSolverStopTime(&(&missileXX15_M)
      ->solverInfo);

    {
      (&missileXX15_M)->Timing.clockTick1++;
    }
  }
}

void missileXX15ModelClass::missileXX15_derivatives()
{
  missileXX15ModelClass::XDot_missileXX15_T *_rtXdot;
  boolean_T lsat;
  _rtXdot = ((XDot_missileXX15_T *) (&missileXX15_M)->derivs);
  _rtXdot->Integrator6_CSTATE = missileXX15_B.Psidot_m;
  _rtXdot->_CSTATE = missileXX15_B.Thetadot_m;
  _rtXdot->Integrator1_CSTATE[0] = missileXX15_B.Integrator[0];
  _rtXdot->Integrator_CSTATE[0] = missileXX15_B.TmpSignalConversionAtIntegrator
    [0];
  _rtXdot->Integrator1_CSTATE[1] = missileXX15_B.Integrator[1];
  _rtXdot->Integrator_CSTATE[1] = missileXX15_B.TmpSignalConversionAtIntegrator
    [1];
  _rtXdot->Integrator1_CSTATE[2] = missileXX15_B.Integrator[2];
  _rtXdot->Integrator_CSTATE[2] = missileXX15_B.TmpSignalConversionAtIntegrator
    [2];
  lsat = (missileXX15_X.Integrator_CSTATE_m <= 0.0);
  if (((!lsat) && (!(missileXX15_X.Integrator_CSTATE_m >= 200.0))) || lsat) {
    _rtXdot->Integrator_CSTATE_m = 1.0;
  } else {
    _rtXdot->Integrator_CSTATE_m = 0.0;
  }

  lsat = (missileXX15_X.Integrator_CSTATE_e <= 0.0);
  if (((!lsat) && (!(missileXX15_X.Integrator_CSTATE_e >= 200.0))) || lsat) {
    _rtXdot->Integrator_CSTATE_e = 1.0;
  } else {
    _rtXdot->Integrator_CSTATE_e = 0.0;
  }

  lsat = (missileXX15_X.Integrator_CSTATE_mt <= 0.0);
  if (((!lsat) && (!(missileXX15_X.Integrator_CSTATE_mt >= 200.0))) || lsat) {
    _rtXdot->Integrator_CSTATE_mt = 1.0;
  } else {
    _rtXdot->Integrator_CSTATE_mt = 0.0;
  }

  lsat = (missileXX15_X.Integrator_CSTATE_g <= 0.0);
  if (((!lsat) && (!(missileXX15_X.Integrator_CSTATE_g >= 200.0))) || lsat) {
    _rtXdot->Integrator_CSTATE_g = 1.0;
  } else {
    _rtXdot->Integrator_CSTATE_g = 0.0;
  }
}

void missileXX15ModelClass::initialize()
{
  rt_InitInfAndNaN(sizeof(real_T));

  {
    rtsiSetSimTimeStepPtr(&(&missileXX15_M)->solverInfo, &(&missileXX15_M)
                          ->Timing.simTimeStep);
    rtsiSetTPtr(&(&missileXX15_M)->solverInfo, &rtmGetTPtr((&missileXX15_M)));
    rtsiSetStepSizePtr(&(&missileXX15_M)->solverInfo, &(&missileXX15_M)
                       ->Timing.stepSize0);
    rtsiSetdXPtr(&(&missileXX15_M)->solverInfo, &(&missileXX15_M)->derivs);
    rtsiSetContStatesPtr(&(&missileXX15_M)->solverInfo, (real_T **)
                         &(&missileXX15_M)->contStates);
    rtsiSetNumContStatesPtr(&(&missileXX15_M)->solverInfo, &(&missileXX15_M)
      ->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&(&missileXX15_M)->solverInfo,
      &(&missileXX15_M)->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&(&missileXX15_M)->solverInfo,
      &(&missileXX15_M)->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&(&missileXX15_M)->solverInfo,
      &(&missileXX15_M)->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&(&missileXX15_M)->solverInfo, (&rtmGetErrorStatus
      ((&missileXX15_M))));
    rtsiSetRTModelPtr(&(&missileXX15_M)->solverInfo, (&missileXX15_M));
  }

  rtsiSetSimTimeStep(&(&missileXX15_M)->solverInfo, MAJOR_TIME_STEP);
  (&missileXX15_M)->intgData.f[0] = (&missileXX15_M)->odeF[0];
  (&missileXX15_M)->contStates = ((X_missileXX15_T *) &missileXX15_X);
  rtsiSetSolverData(&(&missileXX15_M)->solverInfo, static_cast<void *>
                    (&(&missileXX15_M)->intgData));
  rtsiSetSolverName(&(&missileXX15_M)->solverInfo,"ode1");
  rtmSetTPtr((&missileXX15_M), &(&missileXX15_M)->Timing.tArray[0]);
  (&missileXX15_M)->Timing.stepSize0 = 1.0;
  rtmSetFirstInitCond((&missileXX15_M), 1);
  missileXX15_PrevZCX.SampleandHold_Trig_ZCE_a = POS_ZCSIG;
  missileXX15_PrevZCX.SampleandHold_Trig_ZCE = POS_ZCSIG;
  if (rtmIsFirstInitCond((&missileXX15_M))) {
    missileXX15_X.Integrator6_CSTATE = 0.0;
    missileXX15_X._CSTATE = 0.0;
  }

  missileXX15_DW.Integrator6_IWORK = 1;
  missileXX15_DW._IWORK = 1;
  if (rtmIsFirstInitCond((&missileXX15_M))) {
    missileXX15_X.Integrator1_CSTATE[0] = 0.0;
    missileXX15_X.Integrator1_CSTATE[1] = 0.0;
    missileXX15_X.Integrator1_CSTATE[2] = 0.0;
    missileXX15_X.Integrator_CSTATE[0] = 0.0;
    missileXX15_X.Integrator_CSTATE[1] = 0.0;
    missileXX15_X.Integrator_CSTATE[2] = 0.0;
  }

  missileXX15_DW.Integrator1_IWORK = 1;
  missileXX15_DW.Integrator_IWORK = 1;
  missileXX15_X.Integrator_CSTATE_m = 0.0;
  missileXX15_X.Integrator_CSTATE_e = 0.0;
  missileXX15_X.Integrator_CSTATE_mt = 0.0;
  missileXX15_DW.TimeStampA = (rtInf);
  missileXX15_DW.TimeStampB = (rtInf);
  missileXX15_X.Integrator_CSTATE_g = 0.0;
  if (rtmIsFirstInitCond((&missileXX15_M))) {
    rtmSetFirstInitCond((&missileXX15_M), 0);
  }
}

void missileXX15ModelClass::terminate()
{
}

missileXX15ModelClass::missileXX15ModelClass() :
  missileXX15_U(),
  missileXX15_Y(),
  missileXX15_B(),
  missileXX15_DW(),
  missileXX15_X(),
  missileXX15_PrevZCX(),
  missileXX15_M()
{
}

missileXX15ModelClass::~missileXX15ModelClass()
{
}

missileXX15ModelClass::RT_MODEL_missileXX15_T * missileXX15ModelClass::getRTM()
{
  return (&missileXX15_M);
}
