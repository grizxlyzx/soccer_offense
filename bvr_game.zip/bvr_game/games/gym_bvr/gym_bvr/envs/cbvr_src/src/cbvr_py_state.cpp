#include "cbvr.hpp"

namespace ai
{
    //   0.000e+000  1.000e+000  0.000e+000  1.788e+005  1.000e+000  0.000e+000
    //   0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000
    //   0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000
    //   0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000
    //   0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000
    //   0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000
    //   0.000e+000

    //   0.000e+000 -1.000e+000  0.000e+000  0.000e+000         nan
    //          nan  0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000
    //   0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000
    //   0.000e+000  0.000e+000  0.000e+000  0.000e+000  4.941e-324         nan
    //   4.941e-324         nan  0.000e+000  0.000e+000  0.000e+000  0.000e+000
    //   0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000  0.000e+000
    //   0.000e+000  0.000e+000

    CBVR::State CBVR::State::max()
    {

        CBVR::State ret;

        ret.minDistToBorder = 500000.;
        ret.dir.x           = 1;
        ret.dir.y           = 1;

        for( auto &m : ret.myMissiles )
        {
            m.mask    = true;
            m.v.dist  = 500000.;
            m.v.dir.x = 1;
            m.v.dir.y = 1;
        }

        ret.banditDist.mask = true;
        ret.banditDist.v    = 500000.;

        ret.banditDir.mask = true;
        ret.banditDir.v.x  = 1;
        ret.banditDir.v.y  = 1;

        for( auto &m : ret.banditThreats )
        {
            m.mask = true;
            m.v.x  = 1;
            m.v.y  = 1;
        }

        return ret;
    };

    CBVR::State CBVR::State::min()
    {
        CBVR::State ret;

        ret.minDistToBorder = 0.;
        ret.dir.x           = -1;
        ret.dir.y           = -1;

        for( auto &m : ret.myMissiles )
        {
            m.mask    = true;
            m.v.dist  = 0.;
            m.v.dir.x = -1;
            m.v.dir.y = -1;
        }

        ret.banditDist.mask = true;
        ret.banditDist.v    = 0.;

        ret.banditDir.mask = true;
        ret.banditDir.v.x  = -1;
        ret.banditDir.v.y  = -1;

        for( auto &m : ret.banditThreats )
        {
            m.mask = true;
            m.v.x  = -1;
            m.v.y  = -1;
        }

        return ret;
    };

    PyObject *CBVR::State::to_PyList( bool forceMaskToFalse ) const
    {
        int i = 0;

#define SETX( X )                                                                                                      \
    {                                                                                                                  \
        PyObject *f = Py_BuildValue( "d", X );                                                                         \
        PyList_SetItem( RET, i, f );                                                                                   \
        i++;                                                                                                           \
    }
        // 6 means legal actions, -1 for min distance to boarder, 2 for my position, 2 for bandit position,1 for missle count

        PyObject *RET = PyList_New( 49 - 1 + 2 + 2 + 1);

        // SETX(legalActions[0])
        // SETX(legalActions[1])
        // SETX(legalActions[2])
        // SETX(legalActions[3])
        // SETX(legalActions[4])
        // SETX(legalActions[5])
        SETX(missiles_count)

        SETX(myPosition[0])
        SETX(myPosition[1])

        SETX(banditDist.mask ? banditPosition[0] : 0.0)
        SETX(banditDist.mask ? banditPosition[1] : 0.0)

        // SETX( minDistToBorder )
        SETX( dir.x )
        SETX( dir.y )

#define SET_MM( k )                                                                                                    \
    SETX( myMissiles[k].mask && ( !forceMaskToFalse ) ? 1. : 0. )                                                      \
    SETX( myMissiles[k].mask ? myMissiles[k].v.dist : 0. )                                                             \
    SETX( myMissiles[k].mask && ( !forceMaskToFalse ) ? 1. : 0. )                                                      \
    SETX( myMissiles[k].mask ? myMissiles[k].v.dir.x : 0. )                                                            \
    SETX( myMissiles[k].mask && ( !forceMaskToFalse ) ? 1. : 0. )                                                      \
    SETX( myMissiles[k].mask ? myMissiles[k].v.dir.y : 0. )

        SET_MM( 0 )
        SET_MM( 1 )
        SET_MM( 2 )
        SET_MM( 3 )

#undef SET_MM

        SETX( banditDist.mask && ( !forceMaskToFalse ) ? 1. : 0. );
        SETX( banditDist.mask ? banditDist.v : 0 );


        SETX( banditDir.mask && ( !forceMaskToFalse ) ? 1. : 0. );
        SETX( banditDir.mask ? banditDir.v.x : 0 );
        SETX( banditDir.mask && ( !forceMaskToFalse ) ? 1. : 0. );
        SETX( banditDir.mask ? banditDir.v.y : 0 );

#define SET_BM( k )                                                                                                    \
    SETX( banditThreats[k].mask && ( !forceMaskToFalse ) ? 1. : 0. )                                                   \
    SETX( banditThreats[k].mask ? banditThreats[k].v.x : 0 )                                                           \
    SETX( banditThreats[k].mask && ( !forceMaskToFalse ) ? 1. : 0. )                                                   \
    SETX( banditThreats[k].mask ? banditThreats[k].v.y : 0 )

        SET_BM( 0 )
        SET_BM( 1 )
        SET_BM( 2 )
        SET_BM( 3 )



#undef SET_BM
#undef SETX

        return RET;
    };
}; // namespace ai