#include "cbvr.hpp"
#include <iostream>

namespace ai
{

    CBVR::CBVR( const dvec3 &redPos, const dvec3 &redDir, const dvec3 &bluePos, const dvec3 &blueDir )
        : m_Red( std::make_unique<Aircraft>( 90., 150000, .7, redPos, redDir ) )
        , m_Blue( std::make_unique<Aircraft>( 90., 150000, .7, bluePos, blueDir ) )
        , m_RedMissiles()
        , m_BlueMissiles(){};

    CBVR::Result CBVR::step( const Aircraft::Action redAction, const Aircraft::Action blueAction )
    {
        CBVR::Result ret = CBVR::Result::Normal;
        
        if (!red_is_down){
            if( auto m = m_Red->step( redAction, *m_Blue, m_FrameIdx ); m )
            {
                m_RedMissiles.emplace_back( std::move( m ) );
                ret = Result::RedFired;
            }
        }

        if (!blue_is_down){
            if( auto m = m_Blue->step( blueAction, *m_Red, m_FrameIdx ); m )
            {
                m_BlueMissiles.emplace_back( std::move( m ) );
                ret = Result::BlueFired;
            }
        }

        

        for( auto &m : m_RedMissiles )
        {
            m->step( red_is_down,*m_Red, *m_Blue, m_FrameIdx );

        }

        for( auto &m : m_BlueMissiles )
        {
            m->step( blue_is_down,*m_Blue, *m_Red, m_FrameIdx );
        }

        // check if within battle field;
        auto pos = m_Red->position();
        if( pos.x < -BattleFieldSize.x / 2. || pos.x > BattleFieldSize.x / 2. || pos.y < -BattleFieldSize.y / 2. ||
            pos.y > BattleFieldSize.y / 2. )
        {
            return Result::RedOutOfArea;
        }

        pos = m_Blue->position();
        if( pos.x < -BattleFieldSize.x / 2. || pos.x > BattleFieldSize.x / 2. || pos.y < -BattleFieldSize.y / 2. ||
            pos.y > BattleFieldSize.y / 2. )
        {
            return Result::BlueOutOfArea;
        }

        
        if (red_is_down){
            m_Red->m_MissileCount = 0.0;
        }

        if (blue_is_down){
            m_Blue->m_MissileCount = 0.0;
        }

        auto IsBlueMissileRunning = false;

        for(const auto &m:m_BlueMissiles){  
            if (!m ->isStopped()){
                IsBlueMissileRunning = true;
            }
        }

        auto IsRedMissileRunning = false;
        for (const auto &m:m_RedMissiles){
            if(!m->isStopped()){
                IsRedMissileRunning = true;
            }
        }

        for( const auto &m : m_RedMissiles )
        {
            if( m->isHit() )
            {
                blue_is_down = true;
            }
        }

        for( const auto &m : m_BlueMissiles )
        {
            if( m->isHit() )
            {
                red_is_down = true;
            }
        }

        if (blue_is_down && red_is_down){
            return Result::Draw;
        }

        if (blue_is_down && !IsBlueMissileRunning){
            return Result::RedHitByMissile;
        }

        if (red_is_down && !IsRedMissileRunning){
            return Result::BlueHitByMissile;
        }
        


        if (!IsBlueMissileRunning && !IsRedMissileRunning && m_Blue->m_MissileCount == 0 && m_Red->m_MissileCount == 0){
            return Result::Draw;
        }



        // if (m_Blue -> m_MissileCount == 0 && m_Red -> m_MissileCount == 0){
        //     return Result::Draw;
        // }
        // check if exceeds max # of frames;
        // if( m_FrameIdx > MAX_STEP)
        // {
        //     return Result::Timeout;
        // }

        m_FrameIdx++;
        return ret;
    };

}; // namespace ai