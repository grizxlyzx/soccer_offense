#include "ac.hpp"

#include <glm/ext.hpp>
#include <glm/ext/matrix_transform.hpp>

namespace ai
{

    // std::shared_ptr<Missile> Aircraft::step( const Action action, const Aircraft &target, unsigned int frameIndex )
    std::unique_ptr<Missile> Aircraft::step( const Action action, const Aircraft &target, unsigned int frameIndex )
    {
        auto speed = m_Speed;

        auto fire             = static_cast<int>( action ) % 2 == 1;
        m_LastDirectionAction = static_cast<Action>( static_cast<int>( action ) >> 1 << 1 );



        if( m_LastDirectionAction != Action::Straight )
        {
            speed *= m_TurningSpeedReduceFactor;

            auto a = glm::radians( TurningAngle * ( m_LastDirectionAction == Action::LeftTurn ? 1. : -1. ) );

            auto r = glm::rotate( glm::identity<glm::dmat4>(), a, dvec3( 0., 0., 1. ) );

            m_LastIndexDirection = m_Direction;
            m_Direction = r * glm::dvec4( m_Direction, 1 );
        }

        m_Position += m_Direction * speed;

        if( !fire || !inMyRadar( target.position() ) || m_MissileCount <= 0.0 )
        {
            return nullptr;
        }

        m_MissileCount -= 1;

        // return std::make_shared<Missile>( *this, target, frameIndex );
        return std::make_unique<Missile>( *this, target, frameIndex );
    };

}; // namespace ai