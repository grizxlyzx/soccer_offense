#include "cbvr.hpp"

#include <algorithm>
#include <glm/glm.hpp>
#include <glm/gtx/intersect.hpp>
#include <iostream>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtx/vector_angle.hpp>


namespace ai
{

    const static dvec3 BorderPlanes[] = {
        { -CBVR::BattleFieldSize.x/2.0, 0, 0 }, { +1, 0, 0 }, // left
        { +CBVR::BattleFieldSize.x/2.0, 0, 0 }, { -1, 0, 0 }, // right
        { 0, -CBVR::BattleFieldSize.y/2.0, 0 }, { 0, -1, 0 }, // top
        { 0, +CBVR::BattleFieldSize.y/2.0, 0 }, { 0, +1, 0 }, // bottom
    };

    static double minDistanceToBorders( const dvec3 &pos, const dvec3 &dir )
    {
        std::array<double, 4> ret = { 0 };
        for( int idx = 0; idx < ret.size(); idx++ )
        {
            auto &dist = ret[idx];
            auto flag  = glm::intersectRayPlane( pos, dir, BorderPlanes[idx * 2], BorderPlanes[idx * 2 + 1], dist );

            if( !flag || dist < 0 )
            {
                dist = CBVR::BattleFieldSize.x * 2;
            }

        }
  
        auto m = std::min_element( ret.cbegin(), ret.cend() );
        return std::min( fabs( *m ), CBVR::BattleFieldSize.x );
    };

    //
    CBVR::State CBVR::getState( bool RedOrBlue ) const
    {
        const auto &me     = RedOrBlue ? m_Red : m_Blue;
        const auto &bandit = RedOrBlue ? m_Blue : m_Red;

        const auto &myMissiles     = RedOrBlue ? m_RedMissiles : m_BlueMissiles;
        const auto &banditMissiles = RedOrBlue ? m_BlueMissiles : m_RedMissiles;

        //
        CBVR::State ret     = { 0 };
        //
        ret.minDistToBorder = minDistanceToBorders( me->position(), me->direction() );
        ret.dir             = me->direction();


        //
        ret.myPosition[0] = me->position()[0] / 180000.0;
        ret.myPosition[1] = me->position()[1] / 90000.0;
        
        ret.banditPosition[0] = bandit ->position()[0] / 180000.0;
        ret.banditPosition[1] = bandit ->position()[0] / 90000.0;

        // get legal actions

        // auto left_turn = glm::radians(10.0);
        // auto right_turn = glm::radians(-10.0);

        // auto left_r = glm::rotate( glm::identity<glm::dmat4>(), left_turn , dvec3( 0., 0., 1. ) );
        // auto right_r = glm::rotate( glm::identity<glm::dmat4>(), right_turn , dvec3( 0., 0., 1. ) );

        // auto left_dir = left_r * glm::dvec4( me->direction(), 1 );
        // auto right_dir = right_r * glm::dvec4( me->direction(), 1 );

        // auto left_distance = minDistanceToBorders(me->position(),left_dir);
        // auto right_distance = minDistanceToBorders(me->position(),right_dir);

        // qie bian fei xing


        // if (ret.minDistToBorder <= 5000.0 || right_distance <= 5000.0 || left_distance <= 5000.0){
        //     {
        //         ret.legalActions[0] = 1.0;
        //         ret.legalActions[1] = 0.0;
        //         ret.legalActions[2] = 0.0;
        //         ret.legalActions[3] = 0.0;
        //         ret.legalActions[4] = 0.0;
        //         ret.legalActions[5] = 0.0;
        //         //std::cout << "current player:" << RedOrBlue << " cur direction " << glm::to_string(me->direction()) << " left " << left_distance << " right " << right_distance << " stright " << ret.minDistToBorder << std::endl;
            
        //     }
        // }




        // as missile is empty,set legactions fire to 0.
        // if (me->m_MissileCount <= 0.0) {

        //     ret.legalActions[1] = 0.0;
        //     ret.legalActions[3] = 0.0;
        //     ret.legalActions[5] = 0.0;
        // }


        // ret.missiles_left = me->m_MissileCount;
        ret.missiles_count = me -> m_MissileCount / 4.0;


        //
        int count = 0;
        for( auto &m : ret.myMissiles )
        {
            m.mask    = false;
            m.v.dir.x = 0.;
            m.v.dir.y = 0.;
            m.v.dist  = 0.;
        }

        //
        for( int idx = 0; idx < myMissiles.size() && count < 4; idx++ )
        {
            const auto &m = myMissiles[idx];
            if( !m->isStopped() )
            {
                auto v    = m->position() - me->position();
                auto dist = fabs( glm::length( v ) );
                if( dist > 0 )
                {   
                    ret.myMissiles[count].mask   = true;
                    ret.myMissiles[count].v.dist = std::min( dist/500000. ,1.0);
                    ret.myMissiles[count].v.dir  = glm::normalize( glm::dvec2( v.x, v.y ) );
                    count++;
                }
            }
        }

        ret.banditDist.mask = false;
        ret.banditDist.v    = 0;

        ret.banditDir.mask = false;
        ret.banditDir.v.x  = 0.;
        ret.banditDir.v.y  = 0.;

        if( me->inMyRadar( bandit->position() ) )
        {
            auto v              = bandit->position() - me->position();
            ret.banditDist.mask = true;
            ret.banditDist.v    = std::min( fabs( glm::length( v ) )/500000. ,1.0);
            ret.banditDir.mask  = true;
            ret.banditDir.v     = glm::normalize( glm::dvec2( v.x, v.y ) );
        }
        else
        {
            if( bandit->inMyRadar( me->position() ) )
            {
                auto v             = bandit->position() - me->position();
                ret.banditDir.mask = true;
                ret.banditDir.v    = glm::normalize( glm::dvec2( v.x, v.y ) );
            }
        }

        for( auto &m : ret.banditThreats )
        {
            m.mask = false;
            m.v.x  = 0;
            m.v.y  = 0;
        }
        
        //
        count = 0;
        for( int idx = 0; idx < banditMissiles.size() && count < 4; idx++ )
        {
            const auto &m = banditMissiles[idx];
            if( !m->isStopped() )
            {
                auto v    = m->position() - me->position();
                auto dist = fabs( glm::length( v ) );

                if( dist < 20000 && dist > 0 )
                {
                    ret.banditThreats[count].mask = true;
                    ret.banditThreats[count].v    = glm::normalize( glm::dvec2( v.x, v.y ) );
                    count++;
                }
            }
        }

        return ret;
    };

}; // namespace ai