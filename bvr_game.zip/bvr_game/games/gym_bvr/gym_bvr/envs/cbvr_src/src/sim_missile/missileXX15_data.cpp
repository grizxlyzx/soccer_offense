#include "missileXX15.h"
#include "missileXX15_private.h"

const missileXX15ModelClass::ConstP_missileXX15_T missileXX15_ConstP{

  { 0.2, 0.4 },


  { 1.5, 6.0 },


  { 0.02, 0.025, 0.035, 0.04, 0.045, 0.046, 0.047 },


  { 0.8, 1.2, 2.0, 3.0, 4.0, 5.0, 6.0 }
};
