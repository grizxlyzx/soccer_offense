#include "missile.hpp"

#include "ac.hpp"
#include "sim_missile/missileXX15.h"

namespace ai
{

    using Input = SimMissile::ExtU_missileXX15_T;

    Missile::~Missile() = default;
    // {
    //     delete m_Sim;
    // }

    Missile::Missile( const Aircraft &plat, const Aircraft &target, unsigned int frameIndex )
        : m_Sim( std::make_unique<SimMissile>() )
        // : m_Sim( new SimMissile() )
        , m_GuidedFrameIndices()
        , m_Position( plat.position() )
        , m_Stop( false )
        , m_Hit( false )
        , m_LastTargetPosition( target.position() )
        , m_LastTargetDir( target.direction() )
        , m_LastTargetSpeed( target.speed() )
    {
        m_Sim->initialize();

        Input in = { 0 };

        in.XYZ0[0] = plat.position().x;
        in.XYZ0[1] = plat.position().y;
        in.XYZ0[2] = -plat.position().z;

        dvec3 speed = dvec3(
            plat.direction().x * plat.speed(), plat.direction().y * plat.speed(), plat.direction().z * plat.speed() );

        in.Vxyz0[0] = speed.x;
        in.Vxyz0[1] = speed.y;
        in.Vxyz0[2] = -speed.z;

        in.Euler0[2] = glm::degrees( atan2f( plat.direction().y, plat.direction().x ) );

        m_Sim->setExternalInputs( &in );
        m_Sim->step();

        const auto &out = m_Sim->getExternalOutputs();
        m_Stop          = out.Stop;
        m_Hit           = out.Hit;
        m_Position      = dvec3( out.XYZ[0], out.XYZ[1], -out.XYZ[2] );

        m_GuidedFrameIndices.push_back( frameIndex );
    };

    void Missile::step( const bool IsDown,const Aircraft &plat, const Aircraft &target, unsigned int frameIndex )
    {
        if( m_Stop )
        {
            return;
        }

        if( plat.inMyRadar( target.position() ) && !IsDown )
        {
            m_LastTargetPosition = target.position();
            m_LastTargetDir      = target.direction();
            m_LastTargetSpeed    = target.speed();

            m_GuidedFrameIndices.push_back( frameIndex );
        }

        dvec3 speed = dvec3(
            m_LastTargetDir.x * m_LastTargetSpeed, m_LastTargetDir.y * m_LastTargetSpeed,
            m_LastTargetDir.z * m_LastTargetSpeed );

        Input in = { 0 };

        in.XYZT[0] = m_LastTargetPosition.x;
        in.XYZT[1] = m_LastTargetPosition.y;
        in.XYZT[2] = -m_LastTargetPosition.z;

        in.VxyzT[0] = speed.x;
        in.VxyzT[1] = speed.y;
        in.VxyzT[2] = -speed.z;

        m_Sim->setExternalInputs( &in );
        m_Sim->step();

        const auto &out = m_Sim->getExternalOutputs();
        m_Stop          = out.Stop;
        m_Hit           = out.Hit;
        m_Position      = dvec3( out.XYZ[0], out.XYZ[1], -out.XYZ[2] );
    };

}; // namespace ai