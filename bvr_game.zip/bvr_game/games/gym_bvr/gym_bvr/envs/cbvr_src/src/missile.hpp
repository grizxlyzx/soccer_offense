#pragma once

#include <vector>
#include <memory>

#include "sim_missile/missileXX15.h"
#include "common.hpp"

namespace ai
{
    using SimMissile = missileXX15ModelClass;

    class Aircraft;

    class Missile
    {
    public:
        Missile( const Aircraft &plat, const Aircraft &target, unsigned int frameIndex );
        ~Missile();

        // Missile( Missile && ) = default;
        // Missile &operator=( Missile && ) = default;

        const auto &position() const
        {
            return m_Position;
        };

        const auto isStopped() const
        {
            return m_Stop;
        };

        const auto isHit() const
        {
            return m_Hit;
        };

        const auto guidedFrames() const
        {
            return m_GuidedFrameIndices;
        };

        void step( const bool IsDown,const Aircraft &plat, const Aircraft &target, unsigned int frameIndex );

    private:
        std::unique_ptr<SimMissile> m_Sim;
        // SimMissile *m_Sim;
        std::vector<unsigned int> m_GuidedFrameIndices;

        dvec3 m_Position;
        bool m_Stop;
        bool m_Hit;

        dvec3 m_LastTargetPosition;
        dvec3 m_LastTargetDir;
        double m_LastTargetSpeed;
    };

}; // namespace ai