#ifndef RTW_HEADER_missileXX15_h_
#define RTW_HEADER_missileXX15_h_
#include <cmath>
#include <emmintrin.h>
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "missileXX15_types.h"
#include "rt_nonfinite.h"
#include "rt_defines.h"

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

#ifndef ODE1_INTG
#define ODE1_INTG

struct ODE1_IntgData {
  real_T *f[1];
};

#endif

class missileXX15ModelClass
{
 public:
  struct B_missileXX15_T {
    real_T Integrator[3];
    real_T TmpSignalConversionAtIntegrator[3];
    real_T Y[9];
    real_T In;
    real_T Thetadot_m;
    real_T Psidot_m;
    real_T V_m;
    boolean_T In_p;
  };

  struct DW_missileXX15_T {
    real_T TimeStampA;
    real_T LastUAtTimeA;
    real_T TimeStampB;
    real_T LastUAtTimeB;
    int_T Integrator6_IWORK;
    int_T _IWORK;
    int_T Integrator1_IWORK;
    int_T Integrator_IWORK;
  };

  struct X_missileXX15_T {
    real_T Integrator6_CSTATE;
    real_T _CSTATE;
    real_T Integrator1_CSTATE[3];
    real_T Integrator_CSTATE[3];
    real_T Integrator_CSTATE_m;
    real_T Integrator_CSTATE_e;
    real_T Integrator_CSTATE_mt;
    real_T Integrator_CSTATE_g;
  };

  struct XDot_missileXX15_T {
    real_T Integrator6_CSTATE;
    real_T _CSTATE;
    real_T Integrator1_CSTATE[3];
    real_T Integrator_CSTATE[3];
    real_T Integrator_CSTATE_m;
    real_T Integrator_CSTATE_e;
    real_T Integrator_CSTATE_mt;
    real_T Integrator_CSTATE_g;
  };

  struct XDis_missileXX15_T {
    boolean_T Integrator6_CSTATE;
    boolean_T _CSTATE;
    boolean_T Integrator1_CSTATE[3];
    boolean_T Integrator_CSTATE[3];
    boolean_T Integrator_CSTATE_m;
    boolean_T Integrator_CSTATE_e;
    boolean_T Integrator_CSTATE_mt;
    boolean_T Integrator_CSTATE_g;
  };

  struct PrevZCX_missileXX15_T {
    ZCSigState SampleandHold_Trig_ZCE;
    ZCSigState SampleandHold_Trig_ZCE_a;
  };

  struct ConstP_missileXX15_T {
    real_T uDLookupTable1_tableData[2];
    real_T uDLookupTable1_bp01Data[2];
    real_T uDLookupTable2_tableData[7];
    real_T uDLookupTable2_bp01Data[7];
  };

  struct ExtU_missileXX15_T {
    real_T XYZT[3];
    real_T VxyzT[3];
    real_T XYZ0[3];
    real_T Vxyz0[3];
    real_T Euler0[3];
    real_T H0;
  };

  struct ExtY_missileXX15_T {
    real_T XYZ[3];
    real_T Vxyz[3];
    real_T Euler[3];
    boolean_T Stop;
    boolean_T Hit;
    real_T distance;
  };

  struct RT_MODEL_missileXX15_T {
    const char_T *errorStatus;
    RTWSolverInfo solverInfo;
    X_missileXX15_T *contStates;
    int_T *periodicContStateIndices;
    real_T *periodicContStateRanges;
    real_T *derivs;
    boolean_T *contStateDisabled;
    boolean_T zCCacheNeedsReset;
    boolean_T derivCacheNeedsReset;
    boolean_T CTOutputIncnstWithState;
    real_T odeF[1][12];
    ODE1_IntgData intgData;
    struct {
      int_T numContStates;
      int_T numPeriodicContStates;
      int_T numSampTimes;
    } Sizes;

    struct {
      uint32_T clockTick0;
      time_T stepSize0;
      uint32_T clockTick1;
      boolean_T firstInitCondFlag;
      SimTimeStep simTimeStep;
      boolean_T stopRequestedFlag;
      time_T *t;
      time_T tArray[2];
    } Timing;
  };

  missileXX15ModelClass(missileXX15ModelClass const&) =delete;
  missileXX15ModelClass& operator= (missileXX15ModelClass const&) & = delete;
  missileXX15ModelClass::RT_MODEL_missileXX15_T * getRTM();
  void setExternalInputs(const ExtU_missileXX15_T *pExtU_missileXX15_T)
  {
    missileXX15_U = *pExtU_missileXX15_T;
  }

  const ExtY_missileXX15_T &getExternalOutputs() const
  {
    return missileXX15_Y;
  }

  void initialize();
  void step();
  static void terminate();
  missileXX15ModelClass();
  ~missileXX15ModelClass();
 private:
  ExtU_missileXX15_T missileXX15_U;
  ExtY_missileXX15_T missileXX15_Y;
  B_missileXX15_T missileXX15_B;
  DW_missileXX15_T missileXX15_DW;
  X_missileXX15_T missileXX15_X;
  PrevZCX_missileXX15_T missileXX15_PrevZCX;
  void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si );
  void missileXX15_derivatives();
  RT_MODEL_missileXX15_T missileXX15_M;
};

extern const missileXX15ModelClass::ConstP_missileXX15_T missileXX15_ConstP;

#endif

