#pragma once

#include <glm/glm.hpp>

namespace ai
{
    using dvec3 = glm::dvec3;
};