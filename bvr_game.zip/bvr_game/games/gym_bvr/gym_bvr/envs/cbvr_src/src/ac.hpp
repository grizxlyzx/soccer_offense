#pragma once

#include <memory>
#include <glm/gtx/vector_angle.hpp>

#include "common.hpp"
#include "missile.hpp"

namespace ai
{
    constexpr auto TurningAngle = 10.;

    class Aircraft
    {
    public:
        float m_MissileCount;
        dvec3 m_LastIndexDirection;

        enum class Action : int
        {
            LeftTurn         = 0b0000,
            LeftTurnAndFire  = 0b0001,
            RightTurn        = 0b0010,
            RightTurnAndFire = 0b0011,
            Straight         = 0b0100,
            StraightAndFire  = 0b0101,
        };

        Aircraft(
            const double RadarAngle,               //
            const double RadarRange,               //
            const double TurningSpeedReduceFactor, //
            const dvec3 &p, const dvec3 &d )

            : m_HalfRadarAngleR( glm::radians( RadarAngle / 2. ) )
            , m_RadarRange( RadarRange )
            , m_TurningSpeedReduceFactor( TurningSpeedReduceFactor )
            , m_Position( p )
            , m_Direction( d )
            , m_Speed( 300. )
            , m_MissileCount(4.0)
            , m_LastIndexDirection(0.0,0.0,0.0){};

        inline auto &position() const
        {
            return m_Position;
        };

        inline auto &direction() const
        {
            return m_Direction;
        };

        inline auto speed() const
        {
            if( m_LastDirectionAction != Action::Straight )
                return m_TurningSpeedReduceFactor * m_Speed;

            return m_Speed;
        };

        inline bool inMyRadar( const dvec3 &pos ) const
        {
            auto v = pos - m_Position;
            auto a = glm::angle( glm::normalize( v ), m_Direction );

            return a < m_HalfRadarAngleR && glm::length( v ) < m_RadarRange;
        };

        // std::shared_ptr<Missile> Aircraft::step( const Action action, const Aircraft &target, unsigned int frameIndex
        // );
        std::unique_ptr<Missile> step( const Action action, const Aircraft &target, unsigned int frameIndex );

    private:
        double m_Speed = 300.;
        Action m_LastDirectionAction;

        dvec3 m_Position;
        dvec3 m_Direction;

        double m_HalfRadarAngleR;
        double m_RadarRange;
        double m_TurningSpeedReduceFactor;
        

    };
}; // namespace ai