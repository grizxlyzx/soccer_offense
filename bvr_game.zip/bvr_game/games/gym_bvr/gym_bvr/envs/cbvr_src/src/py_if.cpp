#define PY_SSIZE_T_CLEAN
#include <Python.h>

#include <array>
#include <string>
#include <vector>
#include <memory>
#include <iostream>

#include "cbvr.hpp"

static std::unique_ptr<ai::CBVR> g_bvr = nullptr;

extern "C"
{
    static PyObject *py_max_state( PyObject *, PyObject *args )
    {
        std::cout << "in py_max_state" << std::endl;
        return ai::CBVR::State::max().to_PyList();
    };

    static PyObject *py_min_state( PyObject *, PyObject *args )
    {
        return ai::CBVR::State::min().to_PyList( true );
    };

    static PyObject *py_create( PyObject *, PyObject *args )
    {
        ai::dvec3 redPos;
        ai::dvec3 redDir;
        ai::dvec3 bluePos;
        ai::dvec3 blueDir;


        if( !PyArg_ParseTuple(
                args, "(ddd)(ddd)(ddd)(ddd)",       //
                &redPos.x, &redPos.y, &redPos.z,    //
                &redDir.x, &redDir.y, &redDir.z,    //
                &bluePos.x, &bluePos.y, &bluePos.z, //
                &blueDir.x, &blueDir.y, &blueDir.z ) )
        {
            return NULL;
        }

        g_bvr = std::make_unique<ai::CBVR>( redPos, redDir, bluePos, blueDir );


        Py_RETURN_NONE;
    };

    //
    // @arguments:
    //      (red_action, blue_action) action pair;
    // @return:
    //      Sim result;
    //
    static PyObject *py_step( PyObject *, PyObject *args )
    {
        int redAction  = 0;
        int blueAction = 0;

        if( !PyArg_ParseTuple(
                args, "(ii)", //
                &redAction, &blueAction ) )
            return NULL;

        auto ret = g_bvr->step(
            static_cast<ai::Aircraft::Action>( redAction ), static_cast<ai::Aircraft::Action>( blueAction ) );

        return PyLong_FromLong( static_cast<int>( ret ) );
    };

    static PyObject *py_get_state( PyObject *, PyObject *args )
    {
        unsigned char redOrBlue = true;
        if( !PyArg_ParseTuple(
                args, "b", //
                &redOrBlue ) )
            return NULL;

        auto ret = g_bvr->getState( redOrBlue );
        return ret.to_PyList();
    };

    static PyObject *py_get_ac_position( PyObject *, PyObject *args )
    {
        unsigned char redOrBlue = true;
        if( !PyArg_ParseTuple(
                args, "b", //
                &redOrBlue ) )
            return NULL;

        auto pos = g_bvr->getAircraftPosition( redOrBlue );
        return Py_BuildValue(
            "(ddd)", //
            pos.x, pos.y, pos.z );
    };

    static PyObject *py_get_ac_direction( PyObject *, PyObject *args )
    {
        unsigned char redOrBlue = true;
        if( !PyArg_ParseTuple(
                args, "b", //
                &redOrBlue ) )
            return NULL;

        auto dir = g_bvr->getAircraftDirection( redOrBlue );
        return Py_BuildValue(
            "(ddd)", //
            dir.x, dir.y, dir.z );
    };

    static PyObject *py_get_missiles_positions( PyObject *, PyObject *args )
    {
        unsigned char redOrBlue = true;
        if( !PyArg_ParseTuple(
                args, "b", //
                &redOrBlue ) )
            return NULL;

        auto ps   = g_bvr->getLiveMissilesPositions( redOrBlue );
        auto *ret = PyList_New( ps.size() );

        int idx = 0;
        for( const auto p : ps )
        {
            auto e = Py_BuildValue( "(ddd)", p.x, p.y, p.z );
            PyList_SetItem( ret, idx, e );
            idx++;
        }
        return ret;
    };

    static PyObject *py_get_guided_frames( PyObject *, PyObject *args )
    {
        unsigned char redOrBlue = true;
        if( !PyArg_ParseTuple(
                args, "b", //
                &redOrBlue ) )
            return NULL;

        auto fs   = g_bvr->getHitMissileGuidedFrames( redOrBlue );
        auto *ret = PyList_New( fs.size() );

        int idx = 0;
        for( const auto f : fs )
        {
            auto e = Py_BuildValue( "i", f );
            PyList_SetItem( ret, idx, e );
            idx++;
        }
        return ret;
    };

    constexpr auto METHOD_FLAGS  = METH_VARARGS;
    static PyMethodDef Methods[] = {

        { "max_state", (PyCFunction)py_max_state, METHOD_FLAGS, "CBVR max state" }, //
        { "min_state", (PyCFunction)py_min_state, METHOD_FLAGS, "CBVR min state" }, //

        { "create", (PyCFunction)py_create, METHOD_FLAGS, "New CBVR" }, //
        { "step", (PyCFunction)py_step, METHOD_FLAGS, "SIM step." },    //
        { "get_state", (PyCFunction)py_get_state, METHOD_FLAGS, "get state vector of red or blue" },
        // { "reset", (PyCFunction)py_reset, METHOD_FLAGS, "reset" },      //

        { "get_ac_position", (PyCFunction)py_get_ac_position, METHOD_FLAGS, "get position of red or blue" },
        { "get_ac_direction", (PyCFunction)py_get_ac_direction, METHOD_FLAGS, "get direction of red or blue" },
        { "get_missiles_positions", (PyCFunction)py_get_missiles_positions, METHOD_FLAGS,
          "get positions of missiles of red or blue" },

        { "get_guided_frames", (PyCFunction)py_get_guided_frames, METHOD_FLAGS,
          "get guided frames of the hit missile of red or blue" },

        { NULL, NULL, 0, NULL } //
    };

    static auto ModDef = PyModuleDef{
        PyModuleDef_HEAD_INIT, "cbvr", /* name of module */
        NULL,                          /* module documentation, may be NULL */
        -1,                            /* size of per-interpreter state of the module,
                                          or -1 if the module keeps state in global variables. */
        Methods                        // methods
    };

    PyMODINIT_FUNC PyInit_cbvr( void )
    {
        return PyModule_Create( &ModDef );
    };
};
