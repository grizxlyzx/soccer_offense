import missile as m

# pos = (0, 40000, 5000)  # x y z
pos = (175000, 40000, 5000)  # x y z
speed = (-300, 0, 0)
pose = (0, 0, 180)

a = m.create(pos, speed, pose)
print(a)
# targetPos = (75000, 40000, 5000)
targetPos = (0, 40000, 5000)
targetSpeed = (300, 0, 0)

stop = False
time = 0
while not stop:
    time += 1
    targetPos = (targetPos[0] + targetSpeed[0], targetPos[1], targetPos[2])
    stop, hit, dist, mPos = m.step(a, targetPos, targetSpeed)
    # print(stop, hit, dist, mPos)
    print(f"stop:{stop}, hit:{hit}, dist:{dist}, mPos:{mPos}")
    # break

m.release(a)
print(time)
