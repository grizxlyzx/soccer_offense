#pragma once

#include <vector>
#include <array>

#include <Python.h>

#include "ac.hpp"

namespace ai
{
    class CBVR
    {
    public:
        constexpr static glm::dvec2 BattleFieldSize = { 180000, 90000 };

        float red_missile_count{4.0};
        float blue_missile_count{4.0};
        bool red_is_down{false};
        bool blue_is_down{false};

        // constexpr static auto MAX_STEP = 1000;

        enum class Result : int
        {
            RedFired         = -2,
            BlueFired        = -1,
            Normal           = 0,
            RedOutOfArea     = 1,
            BlueOutOfArea    = 2,
            RedHitByMissile  = 3,
            BlueHitByMissile = 4,
            Draw             = 5,
            FindTarget       = 6,
        };

        CBVR( const dvec3 &redPos, const dvec3 &redDir, const dvec3 &bluePos, const dvec3 &blueDir );

        CBVR( const CBVR & ) = delete;
        CBVR &operator=( const CBVR & ) = delete;

        CBVR( CBVR && ) = delete;
        CBVR &operator=( CBVR && ) = delete;

        Result step( const Aircraft::Action redAction, const Aircraft::Action blueAction );

        struct State
        {
            template <typename T>
            struct Masked
            {
                bool mask;
                T v;
            };

            struct MissileInfo
            {
                double dist;
                glm::dvec2 dir;
            };

            // me
            double minDistToBorder;
            glm::dvec2 dir;

            // my missile
            std::array<Masked<MissileInfo>, 4> myMissiles;

            // bandit
            Masked<double> banditDist;
            Masked<glm::dvec2> banditDir;

            // missiles threat me;
            std::array<Masked<glm::dvec2>, 4> banditThreats;
            // legal actions

            // std::vector <double> legalActions{1.,1.,1.,1.,1.,1.};
            std::vector <double> myPosition{0.0,0.0};
            std::vector <double> banditPosition{0.0,0.0};
            float missiles_count{4.0};


            PyObject *to_PyList( bool forceMaskToFalse = false ) const;

            static State max();
            static State min();
        };

        State getState( bool RedOrBlue ) const;

        const dvec3 &getAircraftPosition( bool RedOrBlue ) const
        {
            const auto &ac = RedOrBlue ? m_Red : m_Blue;
            return ac->position();
        };

        const dvec3 &getAircraftDirection( bool RedOrBlue ) const
        {
            const auto &ac = RedOrBlue ? m_Red : m_Blue;
            return ac->direction();
        };

        const std::vector<dvec3> getLiveMissilesPositions( bool RedOrBlue ) const
        {
            std::vector<dvec3> ret;
            const auto &missiles = RedOrBlue ? m_RedMissiles : m_BlueMissiles;
            // printf( "pool %S %p %p==%p\n", RedOrBlue ? "T" : "F", &missiles, &m_RedMissiles, &m_BlueMissiles );
            for( const auto &m : missiles )
            {
                if( !m->isStopped() )
                    ret.push_back( m->position() );
            }
            return ret;
        };

        const std::vector<unsigned int> getHitMissileGuidedFrames( bool RedOrBlue ) const
        {
            const auto &missiles = RedOrBlue ? m_RedMissiles : m_BlueMissiles;
            for( const auto &m : missiles )
            {
                if( m->isHit() )
                {
                    return m->guidedFrames();
                }
            }
            return {};
        };

    private:
        unsigned int m_FrameIdx = 0;

        std::unique_ptr<Aircraft> m_Red;
        std::unique_ptr<Aircraft> m_Blue;

        // std::vector<std::shared_ptr<Missile>> m_RedMissiles;
        // std::vector<std::shared_ptr<Missile>> m_BlueMissiles;
        std::vector<std::unique_ptr<Missile>> m_RedMissiles;
        std::vector<std::unique_ptr<Missile>> m_BlueMissiles;
    };

}; // namespace ai
