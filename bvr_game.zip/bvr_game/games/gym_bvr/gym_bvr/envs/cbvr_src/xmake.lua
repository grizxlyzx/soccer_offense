set_languages("cxx17")

add_includedirs(
    "3rdparty/glm"
)

target("cbvr")
    set_kind("shared")

    local pyVer = "3.9"
    local pyVerNum = "39"

    local fn = "cbvr.pyd"
    if is_plat("windows") then
        set_filename(fn)

        local PyDir = "D:/Anaconda3/envs/bvr"
        add_includedirs(
            "/home/zx/software/anaconda3/envs/rl/include/python3.9"
        )
        add_linkdirs(
            "/home/zx/software/anaconda3/envs/rl/lib/"
        )
        add_links(
            "python"..pyVerNum
        )
    else
        -- TODO: update name and paths, according to ubuntu
        fn = "cbvr.cpython-".. pyVerNum .."-x86_64-linux-gnu.so"
        set_filename(fn)

        add_includedirs(
             "/home/zx/software/anaconda3/envs/rl/include/python3.9/"
        )
        add_linkdirs(
             "/home/zx/software/anaconda3/envs/rl/lib/"
        )
        add_links(
            "python"..pyVer
        )
    end

    add_files("src/**.cpp")
    after_build(function(t)
        local src = "$(buildir)/$(plat)/$(arch)/$(mode)/" .. fn
        print(t:scriptdir())
        os.mv(src, t:scriptdir() .. "./") 
    end)

target_end()
