import time
# import cbvr
from gym_bvr.envs import cbvr
import pathlib
import math

import numpy as np
import pygame

import gym
from gym import spaces

import sys

My_DIR = str(pathlib.Path(__file__).parent)
sys.path.insert(0, My_DIR)

AC_ICON = pygame.image.load(My_DIR + "/air.png")
AC_ICON = pygame.transform.scale(AC_ICON, (50, 50))

RadarAngle = 45
RadarRange = 140000

BG_COLOR = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

BattleField = (180000, 90000, 10000)


# Draw


def draw_missile(screen, map_scale, pos, color):
    m_x, m_y = pos[0] / map_scale, pos[1] / map_scale
    pygame.draw.ellipse(screen, color, ((m_x, m_y), (10, 10)), 0)


def draw_circles(screen, map_scale, pos, color):
    m_x, m_y = pos[0] / map_scale, pos[1] / map_scale
    pygame.draw.circle(screen, color, (m_x, m_y), 200, 1)
    pygame.draw.circle(screen, color, (m_x, m_y), 600, 1)


def draw_ac(screen, map_scale, icon, pos, angle):
    rotated_icon = rot_center(icon, angle)
    screen.blit(rotated_icon,
                (pos[0] / map_scale - 25,
                 pos[1] / map_scale - 25))


def draw_radar(screen, map_scale, pos, angle, color):
    f = RadarRange / map_scale

    for r in range(-1, 2):
        x = pos[0] / map_scale + f * math.cos(
            math.radians(angle + r * RadarAngle))
        y = pos[1] / map_scale + f * math.sin(
            math.radians(angle + r * RadarAngle))

        pygame.draw.line(screen, color,
                         (pos[0] / map_scale, pos[1] / map_scale),
                         (x, y), 2)


class BVR2D(gym.Env):
    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 300}

    def __init__(self):

        pygame.init()
        pygame.display.init()

        self.screen = pygame.display.set_mode((1800, 900))

        # action space
        as_lo = np.array([0, 0], dtype=int)
        as_hi = np.array([5, 5], dtype=int)

        self.action_space = spaces.Box(as_lo, as_hi, dtype=int)

        # observation space
        ob_lo = np.array(cbvr.min_state() + cbvr.min_state(), dtype=float)
        ob_hi = np.array(cbvr.max_state() + cbvr.max_state(), dtype=float)

        self.observation_space = spaces.Box(ob_lo, ob_hi, dtype=float)

        self.map_scale = 100
        self.clock = pygame.time.Clock()
        self.fast = False

    def assign_credits(self, frames, r):
        if len(frames) > 0:
            avg = r / len(frames)
            for idx in range(len(frames)):
                frames[idx][2] += avg

    def reset(self, seed=None, return_info=False):
        self.frameIndex = 0
        super().reset(seed=seed)

        rpos = (np.random.uniform() * -90000, -45000 +
                np.random.uniform() * 45000, 10000)
        rdir = (1, 0, 0)

        bpos = (np.random.uniform() * 90000,
                np.random.uniform() * 45000, 10000)
        bdir = (-1, 0, 0)

        cbvr.create(rpos, rdir, bpos, bdir)
        cbvr.step((4, 4))

        rs = cbvr.get_state(True)
        bs = cbvr.get_state(False)

        return np.array(rs + bs)

    def assign_last_credits(self, frames, reward, redOrBlue):
        pass

    def step(self, action):
        result = cbvr.step((action[0], action[1]))
        done = result > 0
        if done:
            print('.. done.. ')
        # reward
        r_reward = 0
        b_reward = 0
        r_win = 0
        b_win = 0

        if result == -2:
            r_reward -= .5

        if result == -1:
            b_reward -= .5

        if result == 1:
            r_reward -= 0

        if result == 2:
            b_reward -= 0

        if result == 3:
            r_reward += 10
            b_reward -= 10
            r_win = 1

        if result == 4:
            b_reward += 10
            r_reward -= 10
            b_win = 1

        if result == 5:
            b_reward -= 5
            r_reward -= 5

        if self.frameIndex > 1000:
            b_reward -= 1000
            r_reward -= 1000

        ob = np.array(cbvr.get_state(True) +
                      cbvr.get_state(False), dtype=float)

        self.frameIndex += 1
        return ob, r_reward, done, False, {'blue_reward': b_reward, "r_win": r_win, "b_win": b_win}

    def render(self):
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    self.fast = not self.fast

        if not self.fast:
            self.screen.fill(BG_COLOR)

            rpos = cbvr.get_ac_position(True)
            rpos = (rpos[0] + 90000, rpos[1] + 45000)
            rdir = cbvr.get_ac_direction(True)
            ra = math.degrees(math.atan2(rdir[1], rdir[0]))

            bpos = cbvr.get_ac_position(False)
            bpos = (bpos[0] + 90000, bpos[1] + 45000)
            bdir = cbvr.get_ac_direction(False)
            ba = math.degrees(math.atan2(bdir[1], bdir[0]))


            draw_ac(self.screen, self.map_scale, AC_ICON, rpos, ra)
            draw_ac(self.screen, self.map_scale, AC_ICON, bpos, ba)

            draw_circles(self.screen, self.map_scale, rpos, RED)
            draw_circles(self.screen, self.map_scale, bpos, BLUE)

            # draw radars
            draw_radar(self.screen, self.map_scale, rpos, ra, RED)
            draw_radar(self.screen, self.map_scale, bpos, ba, BLUE)

            # draw missile
            for pos in cbvr.get_missiles_positions(True):
                p = (pos[0] + 90000, pos[1] + 45000)
                draw_missile(self.screen, self.map_scale, p, RED)

            #print(f"red missiles {len(cbvr.get_missiles_positions(True))}")

            for pos in cbvr.get_missiles_positions(False):
                p = (pos[0] + 90000, pos[1] + 45000)
                draw_missile(self.screen, self.map_scale, p, BLUE)

            #print(f"blue missiles {len(cbvr.get_missiles_positions(False))}")
            
            pygame.display.update()
            self.clock.tick(30)


def rot_center(image, angle):
    # rotation image
    orig_rect = image.get_rect()  # get icon image size and position
    rot_image = pygame.transform.rotate(image, -angle)
    rot_rect = orig_rect.copy()

    rot_rect.center = rot_image.get_rect().center
    return rot_image.subsurface(rot_rect).copy()
