import numpy as np
import matplotlib.pyplot as plt


r = 0.001


def adv(p1h, p1t, p2h, p2t, a, player, r):
    if player == 1:
        qh = (r * p2h) + (-r * p2t)
        qt = (-r * p2h) + (r * p2t)
        v = (qh * p1h) + (qt * p1t)
    if player == 2:
        qh = (-r * p1h) + (r * p1t)
        qt = (r * p1h) + (-r * p1t)
        v = (qh * p2h) + (qt * p2t)
    return qh - v if a == 'h' else qt - v


def r_trans(pi1, reg1, pi2, reg2, r, eta=0.2):
    return r - (eta * np.log(pi1 / reg1)) + (eta * np.log(pi2 / reg2))


if __name__ == '__main__':
    # player 1 => even, player 2 => odd
    p1h = 0.1
    p1t = 1 - p1h
    p2h = 0.1
    p2t = 1 - p2h
    pi_rec = [(p1h, p2h)]
    for i in range(100000):
        a1 = 'h' if np.random.random() < p1h else 't'
        a2 = 'h' if np.random.random() < p2h else 't'
        r1 = r if a1 == a2 else -r
        r2 = -r1
        r1trans = r_trans()
        adv1_a1 = adv(p1h, p1t, p2h, p2t, a1, 1, r=r1trans)
        adv1_a2 = adv1_a1
        adv2_a1 = adv(p1h, p1t, p2h, p2t, a2, 2, r=r1trans)
        adv2_a2 = adv2_a1
        if a1 == 'h':
            # p1h += adv1_a1
            p1h += p1h * adv1_a1
            p1h = np.clip(p1h, 0, 1)
            p1t = 1 - p1h
        else:
            # p1t += adv1_a1
            p1t += p1t * adv1_a1
            p1t = np.clip(p1t, 0, 1)
            p1h = 1 - p1t

        if a2 == 'h':
            # p2h += adv2_a2
            p2h += p2h * (adv2_a2 - adv1_a2)
            # p2h += p2h * adv1_a2
            p2h = np.clip(p2h, 0, 1)
            p2t = 1 - p2h
        else:
            p2t += p2t * (adv2_a2 - adv1_a2)
            # p2t += p2t * adv2_a2
            # p2t += p2t * adv1_a2
            p2t = np.clip(p2t, 0, 1)
            p2h = 1 - p2t
        pi_rec.append((p1h, p2h))
    pi_rec = np.array(pi_rec)
    # print(adv1_a2, adv2_a1)
    pts_x = pi_rec[:, 0]
    pts_y = pi_rec[:, 1]
    plt.axis('equal')
    plt.xlim([0, 1])
    plt.ylim([0, 1])
    plt.plot(pts_x, pts_y)
    plt.show()